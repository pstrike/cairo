<?php

// ==========================================================================================
// User Profile Theme
// ==========================================================================================

function cairo_social_user_profile($user_fields) {
  $user_fields['user_subtitle'] 	 = esc_html__( 'Subtitle Name', 'cairo' );
  $user_fields['facebook'] 			   = esc_html__( 'Facebook URL', 'cairo' );
  $user_fields['twitter'] 			   = esc_html__( 'Twitter URL', 'cairo' );
  $user_fields['googleplus'] 		   = esc_html__( 'Google Plus URL', 'cairo' );
  $user_fields['linkedin'] 			   = esc_html__( 'Linkedin URL', 'cairo' );
  $user_fields['tumblr'] 			     = esc_html__( 'Tumblr URL', 'cairo' );
  $user_fields['pinterest'] 		   = esc_html__( 'Pinterest URL', 'cairo' );
  $user_fields['instagram'] 		   = esc_html__( 'Instagram URL', 'cairo' );
  $user_fields['youtube'] 			   = esc_html__( 'Youtube URL', 'cairo' );
  $user_fields['vimeo'] 			     = esc_html__( 'Vimeo URL', 'cairo' );
  return $user_fields;
}
add_action( 'user_contactmethods', 'cairo_social_user_profile' );

// function for registering shortcode
function codepages_register_shortcode() {
  // register shortcode [dropcap]word[/dropcap]
  add_shortcode( 'dropcap', 'codepages_shortcode' );
}

// action for registering shortcode
add_action( 'init', 'codepages_register_shortcode' );

// main function for codepages shortcode
function codepages_shortcode( $args, $content ) {
	// left trim $content
	$codepages_shortcoded_content = ltrim ( $content );

	// select first letter of shortcoded $content
	$codepages_first_letter_of_shortcoded_content = mb_substr( $codepages_shortcoded_content, 0, 1 );

	// select remaining letters of shortcoded content
	$codepages_remaining_letters_of_shortcoded_content = mb_substr( $codepages_shortcoded_content, 1 );

	// add <span class="codepages-dropcap"> to the first letter for shortcoded content
	$codepages_spanned_first_letter = '<span class="codepages-dropcap">' . $codepages_first_letter_of_shortcoded_content . '</span>';

	// return the spanned first letter and remaining letters
	return $codepages_spanned_first_letter . $codepages_remaining_letters_of_shortcoded_content;
}
