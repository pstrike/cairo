<?php

// ==========================================================================================
// Widgets Theme
// ==========================================================================================

// Widgets Require
require_once CP_ROOT .'/' .'widgets/codepages-search.php';
require_once CP_ROOT .'/' .'widgets/codepages-tab-post.php';
require_once CP_ROOT .'/' .'widgets/codepages-facebook.php';
require_once CP_ROOT .'/' .'widgets/codepages-posts.php';
require_once CP_ROOT .'/' .'widgets/codepages-category-posts.php';
require_once CP_ROOT .'/' .'widgets/codepages-slider-posts.php';
require_once CP_ROOT .'/' .'widgets/codepages-social-links.php';
require_once CP_ROOT .'/' .'widgets/codepages-social-count.php';
require_once CP_ROOT .'/' .'widgets/codepages-video.php';
require_once CP_ROOT .'/' .'widgets/codepages-about-me.php';
require_once CP_ROOT .'/' .'widgets/codepages-advertising.php';
require_once CP_ROOT .'/' .'widgets/codepages-instagram.php';
require_once CP_ROOT .'/' .'widgets/codepages-twitter.php';
require_once CP_ROOT .'/' .'widgets/codepages-tag.php';
require_once CP_ROOT .'/' .'widgets/codepages-mailchimp.php';

//Enqueue scripts for file uploader
function codepages_media_upload(){
  wp_enqueue_media();
  wp_enqueue_script('adsScript', plugins_url( '/assets/js/media-uploader.js',(__FILE__) ) );
  wp_enqueue_style('adsCss', plugins_url( '/assets/css/cp-admin.css',(__FILE__) ) );
}
add_action('admin_enqueue_scripts', 'codepages_media_upload');
