<?php

// ==========================================================================================
// Featurd Slider Style
// ==========================================================================================

if(function_exists('vc_map')){
	$posts_list = get_posts(array(
		'orderby' 	=> 'title',
		'order' 	=> 'ASC',
		'post_type' => 'post'
	));
	$posts_array = array();
	$posts_array[__("All Categories", 'cairo')] = "-";
	foreach($posts_list as $post) {
		$posts_array[$post->post_title . " (id:" . $post->ID . ")"] = $post->ID;
	}
	$post_categories = get_terms("category");
	$post_categories_array = array();
	$post_categories_array[__("All Categories", 'cairo')] = "-";
	foreach($post_categories as $post_category) {
		$post_categories_array[$post_category->name] =  $post_category->term_id;
	}

	//Image Creat Thump Parametre
	vc_add_shortcode_param( 'imagethup', 'my_param_settings_field' );
	function my_param_settings_field( $settings, $value ) {
	   return '<div class="my_param_block">'
		.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
		esc_attr( $settings['param_name'] ) . ' ' .
		esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />
		<img src="'.esc_attr( $value ).'">'.
		'</div>'; // This is html markup that will be outputted in content elements edit form
	}

	vc_map( array(
		"name" 			=> esc_html__("Featured Posts", 'cairo'),
		"base" 			=> "codepages_featurd_sliders",
		"class" 		=> "",
		"category" 		=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      	=> "ti ti-layout-slider",
		"description" 	=>esc_html__( 'Featured posts widget.','cairo'),
		"params"		=> array(
			//Featured Style
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'cairo'),
				"description" => esc_html__("Select the design element.",'cairo'),
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Style 1", 'cairo') => "style1",
					esc_html__("Style 2", 'cairo') => "style2",
					esc_html__("Style 3", 'cairo') => "style3",
					esc_html__("Style 4", 'cairo') => "style4",
					esc_html__("Style 5", 'cairo') => "style5",
					esc_html__("Style 6", 'cairo') => "style6",
					esc_html__("Style 7", 'cairo') => "style7",
					esc_html__("Style 8", 'cairo') => "style8",
					esc_html__("Style 9", 'cairo') => "style9",
					esc_html__("Style 10", 'cairo') => "styleten",
					esc_html__("Style 11", 'cairo') => "styleeleven",
				)
			),
			//Style 1
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleoneimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-1.png',
				'dependency' => Array('element' => "style", 'value' => array('style1'))
			),
			//Style 2
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styletwoimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-2.png',
				'dependency' => Array('element' => "style", 'value' => array('style2'))
			),
			//Style 3
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylethereeimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-3.png',
				'dependency' => Array('element' => "style", 'value' => array('style3'))
			),
			//Style 4
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefourimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-4.png',
				'dependency' => Array('element' => "style", 'value' => array('style4'))
			),
			//Style 5
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefiveimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-5.png',
				'dependency' => Array('element' => "style", 'value' => array('style5'))
			),
			//Style 6
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesiximage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-6.png',
				'dependency' => Array('element' => "style", 'value' => array('style6'))
			),
			//Style 7
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesevenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-7.png',
				'dependency' => Array('element' => "style", 'value' => array('style7'))
			),
			//Style 8
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleeightimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-8.png',
				'dependency' => Array('element' => "style", 'value' => array('style8'))
			),
			//Style 9
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesnineimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-9.png',
				'dependency' => Array('element' => "style", 'value' => array('style9'))
			),
			//Style 10
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styletenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-10.png',
				'dependency' => Array('element' => "style", 'value' => array('styleten'))
			),
			//Style 11
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleelevenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-11.png',
				'dependency' => Array('element' => "style", 'value' => array('styleeleven'))
			),

			//Post Rating
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Show Post Review",'cairo'),
				"description" => esc_html__("You can on/off Post Review",'cairo'),
				"param_name" => "postreview",
				"value" => array(
					esc_html__("On", 'cairo') => 'on',
					esc_html__("Off", 'cairo') => 'off',
				),
				'std'   => 'off',
			),

			//Post Count
			array(
				"type"			=>	"textfield",
				"class"			=>	"",
				"heading"		=>	esc_html__('Post Count', 'cairo'),
				"description"	=>  esc_html__('Enter Post Count', 'cairo'),
				"param_name"	=>	"postcount",
				"value"			=>	"",
				"admin_label" => true,
			),

			//Exclude Post
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Exclude Posts",'cairo'),
				"description" => esc_html__("Enter exclude posts(s) id. Separate with commas 1,2,3 etc.",'cairo'),
				'group' => esc_html__("Exclude Settings", 'cairo'),
				"param_name" => "excludeposts",
				"value" => "",
			),
			//Exclude Category
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Exclude Category",'cairo'),
				"description" => esc_html__("Enter exclude category id. Separate with commas 1,2,3 etc.",'cairo'),
				'group' => esc_html__("Exclude Settings", 'cairo'),
				"param_name" => "excludecategory",
				"value" => "",
			),
			//Exclude Tag
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Exclude Tags",'cairo'),
				"description" => esc_html__("Enter the tag slugs you would like to display seperated by comma",'cairo'),
				'group' => esc_html__("Exclude Settings", 'cairo'),
				"param_name" => "excludetag",
				"value" => "",
			),

      //Posts Source
			array(
		  	"type" => "dropdown",
				"heading" => esc_html__("Post Source",'cairo'),
		  	'group' => esc_html__("Post Source", 'cairo'),
		  	"param_name" => "source",
		  	"value" => array(
					'None Select' => 'none',
					'By Category' => 'by-category',
					'By Post ID' => 'by-id',
					'By Tag' => 'by-tag',
					'By Author' => 'by-author',
		  	),
		  	"std" => "most-recent",
		  	"admin_label" => true,
		  	"description" => "Select the source of the posts you'd like to show."
			),

			//Post ID
			array(
				"type"			=>	"textfield",
				"class"			=>	"",
				"heading"		=>	esc_html__('Post ID', 'cairo'),
				"Description"	=>	esc_html__('Enter Post ID', 'cairo'),
				'group' => esc_html__("Post Source", 'cairo'),
				"param_name"	=>	"postid",
				"value"			=>	"",
				"dependency" => Array('element' => "source", 'value' => array('by-id'))
			),

			//Post Tag
			array(
				"type"			=>	"textfield",
				"class"			=>	"",
				"heading"		=>	esc_html__('Tag slugs', 'cairo'),
				"Description"	=>	esc_html__('Enter the tag slugs you would like to display seperated by comma', 'cairo'),
				'group' => esc_html__("Post Source", 'cairo'),
				"param_name"	=>	"posttag",
				"value"			=>	"",
				"dependency" => Array('element' => "source", 'value' => array('by-tag'))
			),

			//By Category Select
			array(
		    "type" => "dropdown",
		    "heading" => esc_html__("Post Categories", 'cairo'),
				"description" => esc_html__("Which categories would you like to show?", 'cairo'),
				'group' => esc_html__("Post Source", 'cairo'),
		    "param_name" => "cat",
		    "value" => $post_categories_array,
		    "dependency" => Array('element' => "source", 'value' => array('by-category'))
			),

			//Authot ID Select
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Author ID's",'cairo'),
				"description" => esc_html__("Enter include author ids.",'cairo'),
				'group' => esc_html__("Post Source", 'cairo'),
				"param_name" => "authorids",
				"value" => "",
				"dependency" => Array('element' => "source", 'value' => array('by-author'))
			),

			//Post Order By
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Post Order By",'cairo'),
				'group' => esc_html__("Post Source", 'cairo'),
				"description" => esc_html__("Post Order By",'cairo'),
				"param_name" => "featuredorderby",
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Date", 'cairo') => 'date',
					esc_html__("Random", 'cairo') => 'rand',
					esc_html__("Comment Count", 'cairo') => 'comment_count',
					)
			),

		)

	));

	// ==========================================================================================
	// Breaking News Style
	// ==========================================================================================

		vc_map( array(
			"name" 					=> esc_html__("Breaking News", 'cairo'),
			"base" 					=> "cairo_breaking_news_module",
			"class" 				=> "",
			"category" 			=> esc_html__("Cairo Theme", 'cairo'),
			"icon"      		=> "ti ti-layout-cta-left",
			"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
			"params"				=> array(
				array(
					"type" => "dropdown",
					"heading" => "Style",
					"param_name" => "style",
					"admin_label" => true,
					"value" => array(
						esc_html__("None Select", 'cairo') => "none",
						esc_html__("style 1", 'cairo') => "style1",
						esc_html__("style 2", 'cairo') => "style2",
					),
					"description" => "This changes the layouts of the grids"
				),
				//Style 1
				array(
					'type'	=> 'imagethup',
					'heading'	=> '',
					'param_name'	=> 'styleoneimage',
					'value' => get_template_directory_uri().'/assets/images/admin/breaking_news/cairo_breaking_news_1.png',
					'dependency' => Array('element' => "style", 'value' => array('style1'))
				),
				//Style 2
				array(
					'type'	=> 'imagethup',
					'heading'	=> '',
					'param_name'	=> 'styletwoimage',
					'value' => get_template_directory_uri().'/assets/images/admin/breaking_news/cairo_breaking_news_2.png',
					'dependency' => Array('element' => "style", 'value' => array('style2'))
				),

				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Title Text",'cairo'),
					"description" => esc_html__("Title Block Text",'cairo'),
					"param_name" => "breakingtitle",
					"value" => "",
				),

				array(
					"type" => "textfield",
					"class" => "",
					"heading" => "Number of posts",
					"param_name" => "postcount",
					"value" => "",
					"description" => "The number of posts to show."
				),

				//Exclude Post
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Exclude Posts",'cairo'),
					"description" => esc_html__("Enter exclude posts(s) id. Separate with commas 1,2,3 etc.",'cairo'),
					'group' => esc_html__("Exclude Settings", 'cairo'),
					"param_name" => "excludeposts",
					"value" => "",
				),
				//Exclude Category
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Exclude Category",'cairo'),
					"description" => esc_html__("Enter exclude category id. Separate with commas 1,2,3 etc.",'cairo'),
					'group' => esc_html__("Exclude Settings", 'cairo'),
					"param_name" => "excludecategory",
					"value" => "",
				),
				//Exclude Tag
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Exclude Tags",'cairo'),
					"description" => esc_html__("Enter the tag slugs you would like to display seperated by comma",'cairo'),
					'group' => esc_html__("Exclude Settings", 'cairo'),
					"param_name" => "excludetag",
					"value" => "",
				),

				array(
					"type" => "dropdown",
					"heading" => esc_html__("Post Source", 'cairo'),
					"description" => esc_html__("Select the source of the posts you'd like to show.", 'cairo'),
					"group" => esc_html__("Post Source", 'cairo'),
					"param_name" => "source",
					"value" => array(
						'None Select' => 'none',
						'By Category' => 'by-category',
						'By Post ID' => 'by-id',
						'By Tag' => 'by-tag',
						'By Author' => 'by-author',
					),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__("Post Categories", 'cairo'),
					"description" => esc_html__("Which categories would you like to show?", 'cairo'),
					'group' => esc_html__("Post Source", 'cairo'),
					"param_name" => "cat",
					"value" => $post_categories_array,
					"dependency" => Array('element' => "source", 'value' => array('by-category'))
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__("Post IDs", 'cairo'),
					"description" => esc_html__("Enter the post IDs you would like to display seperated by comma", 'cairo'),
					'group' => esc_html__("Post Source", 'cairo'),
					"param_name" => "postid",
					"dependency" => Array('element' => "source", 'value' => array('by-id'))
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__("Tag slugs", 'cairo'),
					"description" => esc_html__("Enter the tag slugs you would like to display seperated by comma", 'cairo'),
					'group' => esc_html__("Post Source", 'cairo'),
					"param_name" => "tagslugs",
					"dependency" => Array('element' => "source", 'value' => array('by-tag'))
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__("Author IDs", 'cairo'),
					"description" => esc_html__("Enter the Author IDs you would like to display seperated by comma", 'cairo'),
					'group' => esc_html__("Post Source", 'cairo'),
					"param_name" => "authorids",
					"dependency" => Array('element' => "source", 'value' => array('by-author'))
				),

				//Pos Order By
				array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Post Order By",'cairo'),
				"description" => esc_html__("Post Order By",'cairo'),
				"group" => esc_html__("Post Source", 'cairo'),
				"param_name" => "breakingorderby",
					"value" => array(
						esc_html__("None Select", 'cairo') => "none",
						esc_html__("Date", 'cairo') => 'date',
						esc_html__("Random", 'cairo') => 'rand',
						esc_html__("Comment Count", 'cairo') => 'comment_count',
					)
				),
			),
		)
	);


// ==========================================================================================
// Layout Posts Style
// ==========================================================================================

	vc_map( array(
		"name" 			=> esc_html__("Posts Grid", 'cairo'),
		"base" 			=> "cairo_post_module",
		"class" 		=> "",
		"category" 		=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      	=> "ti ti-layout-grid2",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"		=> array(
			array(
				"type" => "dropdown",
				"heading" => "Style",
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("style 1", 'cairo') => "style1",
					esc_html__("style 2", 'cairo') => "style2",
					esc_html__("style 3", 'cairo') => "style3",
					esc_html__("style 4", 'cairo') => "style4",
					esc_html__("style 5", 'cairo') => "style5",
					esc_html__("style 6", 'cairo') => "style6",
					esc_html__("style 7", 'cairo') => "style7",
				),
				"description" => "This changes the layouts of the grids"
			),
			//Style 1
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleoneimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_1.png',
				'dependency' => Array('element' => "style", 'value' => array('style1'))
			),
			//Style 2
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styletwoimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_2.png',
				'dependency' => Array('element' => "style", 'value' => array('style2'))
			),
			//Style 3
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylethereeimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_3.png',
				'dependency' => Array('element' => "style", 'value' => array('style3'))
			),
			//Style 4
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefourimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_4.png',
				'dependency' => Array('element' => "style", 'value' => array('style4'))
			),
			//Style 5
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefiveimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_5.png',
				'dependency' => Array('element' => "style", 'value' => array('style5'))
			),
			//Style 6
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesiximage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_6.png',
				'dependency' => Array('element' => "style", 'value' => array('style6'))
			),
			//Style 7
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesevenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_7.png',
				'dependency' => Array('element' => "style", 'value' => array('style7'))
			),
			array(
			"type" => "dropdown",
			"heading" => esc_html__("Post Title Style", 'cairo'),
			'group' => esc_html__("Title Settings", 'cairo'),
			"param_name" => "titlestyle",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Style1' => "style1",
				'Style2' => "style2",
				'Style3' => "style3",
				'Style4' => "style4",
				'Style5' => "style5",
				'Style6' => "style6",
				'Style7' => "style7",
			),
			"description" => "This changes the layouts of the grids",
			),
			//Column Style Layout
			array(
				'type'	=> 'dropdown',
				'heading'	=> 'Column Style',
				'param_name'	=> 'columnsection',
				'value' => array(
						esc_html__("None Select", 'cairo') => "none-select",
						esc_html__("Tow Column", 'cairo') => "style1",
						esc_html__("Theree Column", 'cairo') => "style2",
				),
				'dependency' => Array('element' => "style", 'value' => array('style2'))
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Posts Title",'cairo'),
				'group' => esc_html__("Title Settings", 'cairo'),
				"description" => esc_html__("Posts Title",'cairo'),
				"param_name" => "posttitle",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => "Number of posts",
				"param_name" => "pppage",
				"value" => "",
				"description" => "The number of posts to show."
			),
			array(
				"type" => "dropdown",
				"heading" => esc_html__("Post Source", 'cairo'),
				"param_name" => "source",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"value" => array(
					'None Select' => 'none',
					'By Category' => 'by-category',
					'By Post ID' => 'by-id',
					'By Tag' => 'by-tag',
					'By Author' => 'by-author',
				),
				"admin_label" => true,
				"description" => "Select the source of the posts you'd like to show."
			),
			array(
				"type" => "dropdown",
				"heading" => "Post Categories",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"param_name" => "cat",
				"value" => $post_categories_array,
				"description" => "Which categories would you like to show?",
				"dependency" => Array('element' => "source", 'value' => array('by-category'))
			),
			array(
				"type" => "textfield",
				"heading" => "Post IDs",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"param_name" => "post_ids",
				"description" => "Enter the post IDs you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-id'))
			),
			array(
				"type" => "textfield",
				"heading" => "Tag slugs",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"param_name" => "tag_slugs",
				"description" => "Enter the tag slugs you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-tag'))
			),
			array(
				"type" => "textfield",
				"heading" => "Author IDs",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"param_name" => "author_ids",
				"description" => "Enter the Author IDs you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-author'))
			),
			//Pos Order By
			array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Post Order By",'cairo'),
			"description" => esc_html__("Post Order By",'cairo'),
			'group' 		=> esc_html__("Post Filter", 'cairo'),
			"param_name" => "categoryorderby",
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Date", 'cairo') => 'date',
					esc_html__("Random", 'cairo') => 'rand',
					esc_html__("Comment Count", 'cairo') => 'comment_count',
				)
			),
			array(
			"type" => "dropdown",
			"heading" => "Pagination Style",
			"param_name" => "pagination",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Regular Pagination With Ajax' => "style1",
				'Ajax Load More' => "style2",
				'Next Page and Prev Page' => "style3",
				'Regular Pagination Not Ajax' => "style4",
			),
			"description" => "This changes the layouts of the grids",
			),
		),
	)
);

// ==========================================================================================
// Categoy Posts Style
// ==========================================================================================

	vc_map( array(
		"name" 			=> esc_html__("Categoy Posts", 'cairo'),
		"base" 			=> "cairo_category_module",
		"class" 		=> "",
		"category" 		=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      	=> "ti ti-layout",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"		=> array(
			array(
				"type" => "dropdown",
				"heading" => "Style",
				"param_name" => "style",
				'admin_label' => false,
        'weight' => 0,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("style 1", 'cairo') => "style1",
					esc_html__("style 2", 'cairo') => "style2",
					esc_html__("style 3", 'cairo') => "style3",
					esc_html__("style 4", 'cairo') => "style4",
					esc_html__("style 5", 'cairo') => "style5",
					esc_html__("style 6", 'cairo') => "style6",
					esc_html__("style 7", 'cairo') => "style7",
					esc_html__("style 8", 'cairo') => "style8",
					esc_html__("style 9", 'cairo') => "style9",
					esc_html__("style 10", 'cairo') => "styleten",
				),
				"description" => "This changes the layouts of the grids"
			),
			//Style 1
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleoneimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_1.png',
				'dependency' => Array('element' => "style", 'value' => array('style1'))
			),
			//Style 2
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styletwoimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_2.png',
				'dependency' => Array('element' => "style", 'value' => array('style2'))
			),
			//Style 3
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylethereeimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_3.png',
				'dependency' => Array('element' => "style", 'value' => array('style3'))
			),
			//Style 4
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefourimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_4.png',
				'dependency' => Array('element' => "style", 'value' => array('style4'))
			),
			//Style 5
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefiveimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_5.png',
				'dependency' => Array('element' => "style", 'value' => array('style5'))
			),
			//Style 6
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesiximage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_6.png',
				'dependency' => Array('element' => "style", 'value' => array('style6'))
			),
			//Style 7
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesevenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_7.png',
				'dependency' => Array('element' => "style", 'value' => array('style7'))
			),
			//Style 8
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleeightimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_8.png',
				'dependency' => Array('element' => "style", 'value' => array('style8'))
			),
			//Style 9
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesnineimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_9.png',
				'dependency' => Array('element' => "style", 'value' => array('style9'))
			),
			//Style 10
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylestenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_10.png',
				'dependency' => Array('element' => "style", 'value' => array('styleten'))
			),

			//Column Style Layout
			array(
				'type'	=> 'dropdown',
				'heading'	=> 'Column Style',
				'param_name'	=> 'columnsection',
				'value' => array(
						esc_html__("None Select", 'cairo') => "none-select",
						esc_html__("Theree Column", 'cairo') => "style1",
						esc_html__("Four Column", 'cairo') => "style2",
				),
				'dependency' => Array('element' => "style", 'value' => array('style3','style5'))
			),

			//Author Images Settings
			array(
			"type" => "dropdown",
			"heading" => "Author Images Settings",
			"param_name" => "autherimgdisplay",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Show' => "show",
				'Hide' => "hide",
			),
			"description" => "Author Images Settings",
			'dependency' => Array('element' => "style", 'value' => array('style1','style2','style9'))
			),

			//Post Rating
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Show Post Review",'cairo'),
				"description" => esc_html__("You can on/off Post Review",'cairo'),
				"param_name" => "postreview",
				"value" => array(
					esc_html__("On", 'cairo') => 'on',
					esc_html__("Off", 'cairo') => 'off',
				),
				'std'   => 'off',
			),

			//Post desc. show/hide
			array(
			"type" => "dropdown",
			"heading" => "Post desc. show/hide.",
			"param_name" => "desdisplay",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Show' => "show",
				'Hide' => "hide",
			),
			"description" => "Post desc. show/hide.",
			'dependency' => Array('element' => "style", 'value' => array('style1','style2','style3','style4','style8','styleten'))
			),

			//Subcategory show/hide
			array(
			"type" => "dropdown",
			"heading" => "Subcategory show/hide.",
			"param_name" => "subcategorydisplay",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Show' => "show",
				'Hide' => "hide",
			),
			"description" => "Subcategory show/hide.",
			'dependency' => Array('element' => "style", 'value' => array('style1','style3','style4'))
			),

			//Post meta show/hide
			array(
			"type" => "dropdown",
			"heading" => "Post meta show/hide.",
			"param_name" => "metadisplay",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Show' => "show",
				'Hide' => "hide",
			),
			"description" => "Post meta show/hide.",
			'dependency' => Array('element' => "style", 'value' => array('style1','style2','style3'))
			),

			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title Text",'cairo'),
				'group' => esc_html__("Title Settings", 'cairo'),
				"description" => esc_html__("Title Block Text",'cairo'),
				"param_name" => "categorytitle",
				"value" => "",
			),
			array(
			"type" => "dropdown",
			"heading" => "Post Title Style",
			'group' => esc_html__("Title Settings", 'cairo'),
			"param_name" => "titlestyle",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Style1' => "style1",
				'Style2' => "style2",
				'Style3' => "style3",
				'Style4' => "style4",
				'Style5' => "style5",
				'Style6' => "style6",
				'Style7' => "style7",
			),
			"description" => "This changes style the block title",
			),

			//Post Count
			array(
				"type"			=>	"textfield",
				"class"			=>	"",
				"heading"		=>	esc_html__('Post Count', 'cairo'),
				'group' 		=> esc_html__("Category Filter", 'cairo'),
				"description"	=>  esc_html__('Enter Post Count', 'cairo'),
				"param_name"	=>	"postcount",
				"value"			=>	"",
				'dependency' => Array('element' => "style", 'value' => array('style4','style5','style3'))
			),
			//Pos Order By
			array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Post Order By",'cairo'),
			'group' => esc_html__("Category Filter", 'cairo'),
			"description" => esc_html__("Post Order By",'cairo'),
			"param_name" => "categoryorderby",
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Date", 'cairo') => 'date',
					esc_html__("Random", 'cairo') => 'rand',
					esc_html__("Comment Count", 'cairo') => 'comment_count',
				)
			),
			array(
				"type" => "dropdown",
				"heading" => "Post Source",
				'group' => esc_html__("Category Filter", 'cairo'),
				"param_name" => "source",
				"value" => array(
					'None Select' => 'none',
					'By Category' => 'by-category',
					'By Post ID' => 'by-id',
					'By Tag' => 'by-tag',
					'By Author' => 'by-author',
				),
				"admin_label" => true,
				"description" => "Select the source of the posts you'd like to show."
			),
			array(
				"type" => "dropdown",
				"heading" => "Post Categories",
				'group' => esc_html__("Category Filter", 'cairo'),
				"param_name" => "cat",
				"value" => $post_categories_array,
				"description" => "Which categories would you like to show?",
				"dependency" => Array('element' => "source", 'value' => array('by-category'))
			),
			//Exclude Category
			array(
				"type" => "textfield",
				"class" => "",
				'group' => esc_html__("Category Filter", 'cairo'),
				"heading" => esc_html__("Exclude Category",'cairo'),
				"description" => esc_html__("Enter exclude category id. Separate with commas 1,2,3 etc.",'cairo'),
				"param_name" => "excludecategory",
				"value" => "",
				"dependency" => Array('element' => "source", 'value' => array('by-category'))
			),
			//Exclude Post
			array(
				"type" => "textfield",
				"class" => "",
				'group' => esc_html__("Category Filter", 'cairo'),
				"heading" => esc_html__("Exclude Posts",'cairo'),
				"description" => esc_html__("Enter exclude posts(s) id. Separate with commas 1,2,3 etc.",'cairo'),
				"param_name" => "excludeposts",
				"value" => "",
				"dependency" => Array('element' => "source", 'value' => array('by-id'))
			),
			//Exclude Tag
			array(
				"type" => "textfield",
				"heading" => "Tag slugs",
				'group' => esc_html__("Category Filter", 'cairo'),
				"param_name" => "excludetag",
				"description" => "Enter the tag slugs you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-tag'))
			),
			//Exclude Author
			array(
				"type" => "textfield",
				"heading" => "Author IDs",
				'group' => esc_html__("Category Filter", 'cairo'),
				"param_name" => "author_ids",
				"description" => "Enter the Author IDs you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-author'))
			),
		),
	));

	// ==========================================================================================
	// Video Format Posts Style
	// ==========================================================================================

		vc_map( array(
			"name" 					=> esc_html__("Video Playlist", 'cairo'),
			"base" 					=> "codepages_video_module",
			"class" 				=> "",
			"category" 			=> esc_html__("Cairo Theme", 'cairo'),
			"icon"      		=> "ti ti-control-forward",
			"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
			"params"				=> array(
				array(
					"type" => "dropdown",
					"heading" => "Style",
					"param_name" => "style",
					"admin_label" => true,
					"value" => array(
						esc_html__("None Select", 'cairo') => "none",
						esc_html__("style 1", 'cairo') => "style1",
						esc_html__("style 2", 'cairo') => "style2",
					),
					"description" => "This changes the layouts of the grids"
				),
				//Style 1
				array(
					'type'	=> 'imagethup',
					'heading'	=> '',
					'param_name'	=> 'styleoneimage',
					'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_video_playlist_1.png',
					'dependency' => Array('element' => "style", 'value' => array('style1'))
				),
				//Style 2
				array(
					'type'	=> 'imagethup',
					'heading'	=> '',
					'param_name'	=> 'styletwoimage',
					'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_video_playlist_2.png',
					'dependency' => Array('element' => "style", 'value' => array('style2'))
				),

				array(
					"type" => "dropdown",
					"heading" => "Dark Or Light",
					"param_name" => "darkorlight",
					"admin_label" => true,
					"value" => array(
						esc_html__("None Select", 'cairo') => "none",
						esc_html__("Dark Style", 'cairo') => "dark",
						esc_html__("Light Style", 'cairo') => "light",
					),
					"description" => "This changes the layouts of the grids"
				),

				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Title Text",'cairo'),
					"description" => esc_html__("Title Block Text",'cairo'),
					"param_name" => "playlisttitle",
					"value" => "",
				),

				array(
					"type" => "textfield",
					"class" => "",
					"heading" => "Number of posts",
					"param_name" => "postcount",
					"value" => "",
					"description" => "The number of posts to show."
				),

				//Exclude Post
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Exclude Posts",'cairo'),
					"description" => esc_html__("Enter exclude posts(s) id. Separate with commas 1,2,3 etc.",'cairo'),
					'group' => esc_html__("Exclude Settings", 'cairo'),
					"param_name" => "excludeposts",
					"value" => "",
				),
				//Exclude Category
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Exclude Category",'cairo'),
					"description" => esc_html__("Enter exclude category id. Separate with commas 1,2,3 etc.",'cairo'),
					'group' => esc_html__("Exclude Settings", 'cairo'),
					"param_name" => "excludecategory",
					"value" => "",
				),
				//Exclude Tag
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Exclude Tags",'cairo'),
					"description" => esc_html__("Enter the tag slugs you would like to display seperated by comma",'cairo'),
					'group' => esc_html__("Exclude Settings", 'cairo'),
					"param_name" => "excludetag",
					"value" => "",
				),

				array(
					"type" => "dropdown",
					"heading" => esc_html__("Post Source", 'cairo'),
					"description" => esc_html__("Select the source of the posts you'd like to show.", 'cairo'),
					"group" => esc_html__("Post Source", 'cairo'),
					"param_name" => "source",
					"value" => array(
						'None Select' => 'none',
						'By Category' => 'by-category',
						'By Post ID' => 'by-id',
						'By Tag' => 'by-tag',
						'By Author' => 'by-author',
					),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__("Post Categories", 'cairo'),
					"description" => esc_html__("Which categories would you like to show?", 'cairo'),
					'group' => esc_html__("Post Source", 'cairo'),
					"param_name" => "cat",
					"value" => $post_categories_array,
					"dependency" => Array('element' => "source", 'value' => array('by-category'))
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__("Post IDs", 'cairo'),
					"description" => esc_html__("Enter the post IDs you would like to display seperated by comma", 'cairo'),
					'group' => esc_html__("Post Source", 'cairo'),
					"param_name" => "postid",
					"dependency" => Array('element' => "source", 'value' => array('by-id'))
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__("Tag slugs", 'cairo'),
					"description" => esc_html__("Enter the tag slugs you would like to display seperated by comma", 'cairo'),
					'group' => esc_html__("Post Source", 'cairo'),
					"param_name" => "tagslugs",
					"dependency" => Array('element' => "source", 'value' => array('by-tag'))
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__("Author IDs", 'cairo'),
					"description" => esc_html__("Enter the Author IDs you would like to display seperated by comma", 'cairo'),
					'group' => esc_html__("Post Source", 'cairo'),
					"param_name" => "authorids",
					"dependency" => Array('element' => "source", 'value' => array('by-author'))
				),

				//Pos Order By
				array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Post Order By",'cairo'),
				"description" => esc_html__("Post Order By",'cairo'),
				"group" => esc_html__("Post Source", 'cairo'),
				"param_name" => "videoorderby",
					"value" => array(
						esc_html__("None Select", 'cairo') => "none",
						esc_html__("Date", 'cairo') => 'date',
						esc_html__("Random", 'cairo') => 'rand',
						esc_html__("Comment Count", 'cairo') => 'comment_count',
					)
				),
			),
		)
	);

	// ==========================================================================================
	// Heading Element
	// ==========================================================================================

	vc_map( array(
		"name" 					=> esc_html__("Heading", 'cairo'),
		"base" 					=> "codepages_heading_module",
		"class" 				=> "",
		"category" 			=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      		=> "ti ti-underline",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"				=> array(
			array(
				"type" => "dropdown",
				"heading" =>  esc_html__("Style Heading",'cairo'),
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("style 1", 'cairo') => "style1",
					esc_html__("style 2", 'cairo') => "style2",
					esc_html__("style 3", 'cairo') => "style3",
					esc_html__("style 4", 'cairo') => "style4",
					esc_html__("style 5", 'cairo') => "style5",
					esc_html__("style 6", 'cairo') => "style6",
					esc_html__("style 7", 'cairo') => "style7",
				),
				"description" => "This changes the layouts of the Heading",
			),

			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title Text",'cairo'),
				"description" => esc_html__("Title Block Text",'cairo'),
				"param_name" => "title_text",
				"value" => "",
			),

			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'cairo'),
				"param_name" => "extra_class",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra ID", 'cairo'),
				"param_name" => "extra_id",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
		),
	));

	// ==========================================================================================
	// Divider Element
	// ==========================================================================================

	vc_map( array(
		"name" 					=> esc_html__("Divider", 'cairo'),
		"base" 					=> "codepages_divider_module",
		"class" 				=> "",
		"category" 			=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      		=> "ti ti-more-alt	",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"				=> array(
			array(
				"type" => "dropdown",
				"heading" =>  esc_html__("Style Divider",'cairo'),
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("style 1", 'cairo') => "style1",
					esc_html__("style 2", 'cairo') => "style2",
					esc_html__("style 3", 'cairo') => "style3",
					esc_html__("style 4", 'cairo') => "style4",
					esc_html__("style 5", 'cairo') => "style5",
					esc_html__("style 6", 'cairo') => "style6",
					esc_html__("style 7", 'cairo') => "style7",
					esc_html__("style 8", 'cairo') => "style8",
					esc_html__("style 9", 'cairo') => "style9",
				),
				"description" => "This changes the layouts of the Divider",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'cairo'),
				"param_name" => "extra_class",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra ID", 'cairo'),
				"param_name" => "extra_id",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
		),
	));

	// ==========================================================================================
	// Instagram Element
	// ==========================================================================================

	vc_map( array(
		"name" 					=> esc_html__("Instagram", 'cairo'),
		"base" 					=> "codepages_instagram_module",
		"class" 				=> "",
		"category" 			=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      		=> "fa fa-instagram",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"				=> array(
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title", 'cairo'),
				"param_name" => "title_insta",
				"value" => "",
				"description" => esc_html__( "add your block title.", 'cairo' ),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Username", 'cairo'),
				"param_name" => "username_insta",
				"value" => "",
				"description" => esc_html__( "add your instagram username.", 'cairo' ),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Number of Photos", 'cairo'),
				"param_name" => "count_img",
				"value" => "",
				"description" => esc_html__( "add namber images show.", 'cairo' ),
			),
			array(
				"type" => "dropdown",
				"heading" =>  esc_html__("Instagram Column",'cairo'),
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Five Columns", 'cairo') => "col-md-2",
					esc_html__("Four Columns", 'cairo') => "col-md-3",
					esc_html__("Three Columns", 'cairo') => "col-md-4",
				),
				"description" => "This changes the layouts of the Instagram",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'cairo'),
				"param_name" => "extra_class",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra ID", 'cairo'),
				"param_name" => "extra_id",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
		),
	));

	// ==========================================================================================
	// MailChimp Moduel Element
	// ==========================================================================================

	vc_map( array(
		"name" 					=> esc_html__("MailChimp", 'cairo'),
		"base" 					=> "codepages_subscribe_mailchimp_module",
		"class" 				=> "",
		"category" 			=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      		=> "ti ti-email",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"				=> array(
			array(
				"type" => "dropdown",
				"heading" =>  esc_html__("Subscribe Style",'cairo'),
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Style 1", 'cairo') => "style1",
					esc_html__("Style 2", 'cairo') => "style2",
				),
				"description" => "This changes the style of Subscribe",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title Subscribe", 'cairo'),
				"param_name" => "title_text",
				"value" => "",
				"description" => esc_html__( "add your title of subscribe.", 'cairo' ),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Description Subscribe", 'cairo'),
				"param_name" => "description_text",
				"value" => "",
				"description" => esc_html__( "add your description of subscribe.", 'cairo' ),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Form ID Subscribe", 'cairo'),
				"param_name" => "formid",
				"value" => "",
				"description" => esc_html__( "add the form id of subscribe.", 'cairo' ),
			),
			array(
				"type" => "dropdown",
				"heading" =>  esc_html__("Subscribe Style",'cairo'),
				"param_name" => "lightordark",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Light", 'cairo') => "light",
					esc_html__("Dark", 'cairo') => "dark",
				),
				"description" => "Select design element light or dark Subscribe",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'cairo'),
				"param_name" => "extra_class",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra ID", 'cairo'),
				"param_name" => "extra_id",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
		),
	));

	// ==========================================================================================
	// Gallery Moduel Element
	// ==========================================================================================

	vc_map( array(
		"name" 					=> esc_html__("Gallery Images", 'cairo'),
		"base" 					=> "codepages_gallery_module",
		"class" 				=> "",
		"category" 			=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      		=> "ti ti-gallery",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"				=> array(
			array(
				"type" => "dropdown",
				"heading" =>  esc_html__("Gallery Style",'cairo'),
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Style 1", 'cairo') => "style1",
					esc_html__("Style 2", 'cairo') => "style2",
				),
				"description" => "This changes the style of Gallery",
			),
			array(
				"type" => "attach_images",
				"heading" =>  esc_html__("Select Images",'cairo'),
				"param_name" => "image",
				"description" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'cairo'),
				"param_name" => "extra_class",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra ID", 'cairo'),
				"param_name" => "extra_id",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
		),
	));

	// ==========================================================================================
	// Natifaction Moduel Element
	// ==========================================================================================

	vc_map( array(
		"name" 					=> esc_html__("Natifaction Box ", 'cairo'),
		"base" 					=> "codepages_alert_module",
		"class" 				=> "",
		"category" 			=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      		=> "ti ti-info-alt",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"				=> array(
			array(
				"type" => "dropdown",
				"heading" =>  esc_html__("Natifaction Types",'cairo'),
				"param_name" => "alert_type",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Success", 'cairo') => "success",
					esc_html__("Info", 'cairo') => "info",
					esc_html__("Warning", 'cairo') => "warning",
					esc_html__("Danger", 'cairo') => "danger",
				),
				"description" => "This changes the style of Natifaction",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Natifaction Text", 'cairo'),
				"param_name" => "alert_text",
				"value" => "",
				"description" => esc_html__( "add your text in natifaction.", 'cairo' ),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'cairo'),
				"param_name" => "extra_class",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra ID", 'cairo'),
				"param_name" => "extra_id",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
		),
	));

	// ==========================================================================================
	// Featured Boxes Element
	// ==========================================================================================

	vc_map( array(
		"name" 					=> esc_html__("Featured Boxes", 'cairo'),
		"base" 					=> "codepages_featured_boxes_module",
		"class" 				=> "",
		"category" 			=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      		=> "ti ti-layout-cta-center",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"				=> array(
			array(
				"type" => "dropdown",
				"heading" =>  esc_html__("Featured Boxes Style",'cairo'),
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("style 1", 'cairo') => "style1",
					esc_html__("style 2", 'cairo') => "style2",
					esc_html__("style 3", 'cairo') => "style3",
				),
				"description" => "This changes the layouts of the Featured Boxes",
			),

			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title Text",'cairo'),
				"description" => esc_html__("Title Block Text",'cairo'),
				"param_name" => "title_text",
				"value" => "",
			),

			array(
				"type" => "vc_link",
				"class" => "",
				"heading" => esc_html__("Link Block Text",'cairo'),
				"description" => esc_html__("Link Block Text",'cairo'),
				"param_name" => "link_block",
				"value" => "",
			),

			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Select Image",'cairo'),
				"description" => esc_html__("Select your image",'cairo'),
				"param_name" => "image",
			),

			array(
				"type" => "textarea_html",
				"class" => "",
				"heading" => esc_html__("Content", 'cairo'),
				"description" => esc_html__("Please, enter content in this element.", 'cairo'),
				"param_name" => "content",
				"value" => "",
				"dependency" => Array('element' => "style", 'value' => array('style2'))
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'cairo'),
				"param_name" => "extra_class",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra ID", 'cairo'),
				"param_name" => "extra_id",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
				'group' => esc_html__("Extra Settings", 'cairo'),
			),
		),
	));

}


add_action('admin_init', 'vc_remove_elements');
function vc_remove_elements() {

	if (!class_exists('WPBakeryVisualComposerAbstract')) { // or using plugins path function
		return;
	}
	// Removing Default shortcodes
	vc_remove_element("vc_wp_search");
	vc_remove_element("vc_wp_recentcomments");
	vc_remove_element("vc_wp_calendar");
	vc_remove_element("vc_wp_pages");
	vc_remove_element("vc_wp_tagcloud");
	vc_remove_element("vc_wp_custommenu");
	vc_remove_element("vc_wp_text");
	vc_remove_element("vc_wp_posts");
	vc_remove_element("vc_wp_links");
	vc_remove_element("vc_wp_categories");
	vc_remove_element("vc_wp_archives");
	vc_remove_element("vc_wp_rss");
	vc_remove_element("vc_teaser_grid");
	vc_remove_element("vc_cta_button");
	vc_remove_element("vc_message");
	vc_remove_element("vc_progress_bar");
	vc_remove_element("vc_pie");
	vc_remove_element("vc_posts_slider");
	vc_remove_element("vc_posts_grid");
	vc_remove_element("vc_images_carousel");
	vc_remove_element("vc_carousel");
	vc_remove_element("vc_cta_button2");
	vc_remove_element("vc_separator");
	vc_remove_element("vc_custom_heading");

    //require_once get_template_directory() .'/inc/visualcomposer-extend.php';
}
