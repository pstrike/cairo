<?php

// ==========================================================================================
// Codepages Social Widget
// ==========================================================================================

add_action( 'widgets_init', 'widget_social_widget' );
function widget_social_widget() {
	register_widget( 'Widget_social_links' );
}
class Widget_social_links extends WP_Widget {
	public function __construct() {
			$widget_ops = array(
				'classname'   => 'widget_social_widget',
				'description' => esc_html_x( 'A short description about you.', 'Tag Cloud widget description', 'codepages' )
			);
			$control_ops = array( 'id_base' => 'widget_social_widget' );
			parent::__construct( 'widget_social_widget', sprintf( esc_html_x( ':. %s - Social Links', 'Social Links widget name', 'codepages' ), CAIRO_THEME_NAME ), $widget_ops, $control_ops );
	 }

	public function widget( $args, $instance ) {
		extract( $args );
		$title     = apply_filters('widget_title', $instance['title'] );
		$layout		 = empty($instance['layout']) ? 'style1' : $instance['layout'];

		echo wp_kses_post( $args['before_widget'] );
			if ( $title )
			echo $before_title.esc_attr($title).$after_title;

			if ( array_key_exists( 'social_url', $instance ) && ! is_array( $instance['social_url'] ) ) {
				$instance['social_url'] = array();
			}
		?>

		<!-- Start widget social -->
		<div class="widget_content">
			<div class="widget-follow">
				<?php if ( ! empty( $instance['social'] ) ): ?>
				<ul class="author-social-icons <?php echo $layout; ?>">
					<?php foreach ( $instance['social'] as $k => $v ): ?>
						<li class="<?php echo sanitize_html_class( $v['icon'] ); ?>"><a href="<?php echo esc_url( $v['url'] ); ?>" target="_blank"><span class="fa fa-<?php echo sanitize_html_class( $v['icon'] ); ?>"></span></a></li>
					<?php endforeach; ?>
				</ul>
			  <?php endif; ?>
			</div>
		</div>
		<!-- End widget social -->

		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	public function update( $new_instance, $old_instance ) {
		$instance                	 	= $old_instance;
		$instance['title']       	 	= strip_tags( $new_instance['title'] );
		$instance['layout']         = strip_tags( $new_instance['layout'] );
		$instance['social']         = array();
		if ( array_key_exists( 'social_url', $new_instance ) && is_array( $new_instance['social_url'] ) ) {
			foreach ( $new_instance['social_url'] as $k => $v ) {
				if ( ! empty( $v ) ) {
					$instance['social'][] = array(
						'icon' => sanitize_key( $new_instance['social_icon'][ $k ] ),
						'url'  => esc_url_raw( $v )
					);
				}
			}
		}
		return $instance;
	}

	public function form( $instance ) {
		$defaults = array( 'title' => 'Subscribe & Follow' );
		$cairo_order        = isset( $instance['layout'] ) ? ( $instance['layout'] ) : 'style1';
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:', 'codepages' ); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo (isset($instance['title'])?esc_attr($instance['title']):""); ?>" class="widefat" type="text">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"><?php esc_html_e( 'Layout Post :', 'cairo' ) ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'layout' ) ); ?>">
				<option value="style1"<?php echo ( $cairo_order == 'style1' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Style 1', 'cairo' ) ?></option>
				<option value="style2"<?php echo ( $cairo_order == 'style2' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Style 2', 'cairo' ) ?></option>
			</select>
		</p>
		<p>
			<?php esc_html_e( 'Social Icons:', 'cairo' ); ?>
		</p>
		<?php
		if ( array_key_exists( 'social', $instance ) && is_array( $instance['social'] ) ) {
			foreach ( $instance['social'] as $k => $v ) {
				$this->social_icon_row( $v['icon'], $v['url'] );
			}
		}
		?>
		<p>
			<a href="#" class="codepages-btn-add-social-icon button"><?php esc_html_e( 'Add Icon', 'cairo' ); ?></a>
		</p>
		<div class="codepages-social-icon-row-instance" style="display:none;">
			<?php $this->social_icon_row(); ?>
		</div>
	<?php
	}

	public function social_icon_row( $selected='', $value='' ) {
		$social = $this->get_social();
		?>
		<div class="codepages-social-icon-row">
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'social_icon' ) ); ?>"><?php esc_html_e( 'Icon', 'cairo' ); ?></label>
				<select id="<?php echo esc_attr( $this->get_field_id( 'social_icon' ) ); ?>" class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'social_icon' ) ); ?>[]">
					<?php foreach ( $social as $k => $v ): ?>
						<option value="<?php echo esc_attr( $k ); ?>"<?php echo ( $k == $selected ) ? ' selected' : ''; ?>><?php echo esc_html( $v ); ?></option>
					<?php endforeach; ?>
				</select>
				<a href="#" class="codepages-social-icon-row-rm">&times;</a>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'social_url' ) ); ?>"><?php esc_html_e( 'Url:', 'cairo' ); ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'social_url' ) ); ?>" class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'social_url' ) ); ?>[]" type="text" value="<?php echo esc_attr( $value ); ?>" />
			</p>
		</div>
		<?php
	}

	public function get_social() {
		$social = array(
			'500px' => '500px',
			'android' => 'Android',
			'apple' => 'Apple',
			'behance' => 'Behance',
			'codepen' => 'Codepen',
			'deviantart' => 'Deviantart',
			'digg' => 'Digg',
			'dribbble' => 'Dribble',
			'dropbox' => 'Dropbox',
			'facebook' => 'Facebook',
			'flickr' => 'Flickr',
			'foursquare' => 'Foursquare',
			'github' => 'Github',
			'google-plus' => 'Google Plus',
			'instagram' => 'Instagram',
			'lastfm' => 'Last FM',
			'linkedin' => 'Linkedin',
			'medium' => 'Medium',
			'odnoklassniki' => 'Odnoklassniki',
			'pinterest' => 'Pinterest',
			'reddit' => 'Reddit',
			'rss' => 'RSS',
			'skype' => 'Skype',
			'slideshare' => 'Slideshare',
			'strava' => 'Strava',
			'soundcloud' => 'Soundcloud',
			'spotify' => 'Spotify',
			'stumbleupon' => 'Stumbleupon',
			'tumblr' => 'Tumblr',
			'twitter' => 'Twitter',
			'vimeo' => 'Vimeo',
			'vine' => 'Vine',
			'vk' => 'VKontakte',
			'whatsapp' => 'Whatsapp',
			'wordpress' => 'Wordpress',
			'snapchat' => 'Snapchat',
			'yahoo' => 'Yahoo',
			'youtube' => 'Youtube'
		);
		return $social;
	}
 }
