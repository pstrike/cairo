<?php

// ==========================================================================================
// Codepages Twitter Widget
// ==========================================================================================

if (!class_exists('codepages_Twitter_Widget')) {
  add_action('widgets_init', 'load_codepages_twitter_widget');
  function load_codepages_twitter_widget()
  {
    register_widget('codepages_Twitter_Widget');
  }
  /** Twitter Widget by codepages **/
  class codepages_Twitter_Widget extends WP_Widget {
    /** Register widget with WordPress. **/
    public function __construct() {
        $widget_ops = array(
          'classname'   => 'codepages_twitter_widget',
          'description' => esc_html_x( 'A short description about you.', 'Twitter widget description', 'codepages' )
        );
        $control_ops = array( 'id_base' => 'codepages_twitter_widget' );
        parent::__construct( 'codepages_twitter_widget', sprintf( esc_html_x( ':. %s - Twitter Feed', 'Twitter widget name', 'codepages' ), CAIRO_THEME_NAME ), $widget_ops, $control_ops );
     }

    public function widget($args, $instance)
    {
      extract( $args );
      $title = apply_filters('widget_title', $instance['title']);
      $username  = isset( $instance['username'] ) ? $instance['username'] : '';
      $number = isset( $instance['number'] ) ? $instance['number'] : '6';

      echo ( $args['before_widget'] );
      if (!empty($title)) {
          echo ( $args['before_title'] . $title . $args['after_title'] );
      }

      $username			           = ot_get_option('twitter_username');
      $consumer_key            = ot_get_option('twitter_consumer_key');
      $consumer_secret         = ot_get_option('twitter_consumer_secret');
      $access_token            = ot_get_option('twitter_access_token');
      $access_secret           = ot_get_option('twitter_access_token_secret');
      $open_new_page    = isset($instance['open_new_page']) ? $instance['open_new_page'] : '';
      $tweets_count     = isset($instance['tweets_count']) ? $instance['tweets_count'] : '2';

      if (!empty($username) &&
        !empty($consumer_key) && !empty($consumer_secret) &&
        !empty($access_token) && !empty($access_secret)) {
        $data = $this->get_data($instance);
        if( $data != false ) {
          echo '<div class="tweet-community"><ul>';
          foreach( $data as $index => $tweet ) {
            if( $index >= $tweets_count ) {
              break;
            }

            if( 'on' == $open_new_page) {
              $tweet->text = preg_replace('/((https?|s?ftp|ssh)\:\/\/[^"\s\<\>]*[^.,;\'">\:\s\<\>\)\]\!])/', '<a target="_blank" href="\\1">\\1</a>', $tweet->text);
              $tweet->text = preg_replace('/\B@([_a-z0-9]+)/i', '<a target="_blank" href="http://twitter.com/\\1">@\\1</a>', $tweet->text);
            }
            else {
              $tweet->text = preg_replace('/((https?|s?ftp|ssh)\:\/\/[^"\s\<\>]*[^.,;\'">\:\s\<\>\)\]\!])/', '<a href="\\1">\\1</a>', $tweet->text);
              $tweet->text = preg_replace('/\B@([_a-z0-9]+)/i', '<a href="http://twitter.com/\\1">@\\1</a>', $tweet->text);
            }
            echo $this->get_li( $tweet, $instance );

          }
          echo '</ul></div>';
        }
      }
      echo wp_kses_post( $args['after_widget'] );
    }

    public function form($instance) {
      $title            = isset($instance['title']) ? $instance['title'] : '';
      $open_new_page    = isset($instance['open_new_page']) ? $instance['open_new_page'] : '';
      $tweets_count     = isset($instance['tweets_count']) ? $instance['tweets_count'] : '2';
      ?>
      <p>
        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title', 'codepages') ?></label>
        <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
          name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($title); ?>"/>
      </p>
      <p>
        <label for="<?php echo esc_attr($this->get_field_id('tweets_count')); ?>"><?php esc_html_e('Number of Tweets', 'codepages') ?></label>
        <input type="text" id="<?php echo esc_attr($this->get_field_id('tweets_count')); ?>"
               name="<?php echo esc_attr( $this->get_field_name('tweets_count') ); ?>" value="<?php echo esc_attr(esc_attr($tweets_count)); ?>" size="3"/>
      </p>
      <p>
        <input type="checkbox" id="<?php echo esc_attr($this->get_field_id('open_new_page')); ?>" name="<?php echo esc_attr($this->get_field_name('open_new_page') ); ?>" <?php checked($open_new_page, 'on'); ?> />
        <label for="<?php echo esc_attr($this->get_field_id('open_new_page')); ?>"><?php esc_html_e('Open Tweet Links in New Page', 'codepages') ?></label>
      </p>
    <?php
    }

    /** Retrieve twitter fresh data **/

    public function get_twitter_data($atts)
    {
      if (!class_exists('OAuthToken')) {
        require_once CP_ROOT . 'composer/assets/oauth/oauth.php';
      }
      require_once CP_ROOT . 'composer/assets/oauth/twitter-oauth.php';
      $twitterConnection = new cairo_TwitterAPIExchange (
        $consumer_key            = ot_get_option('twitter_consumer_key'),
        $consumer_secret         = ot_get_option('twitter_consumer_secret'),
        $access_token            = ot_get_option('twitter_access_token'),
        $access_secret           = ot_get_option('twitter_access_token_secret')
      );
      $username			           = ot_get_option('twitter_username');
      $data = $twitterConnection->get('statuses/user_timeline', array(
        'screen_name' => $username,
        'count' => $atts['tweets_count'],
        'exclude_replies' => false
      ));
      if ($twitterConnection->http_code === 200) {
        return $data;
      }
      return false;
    }

    /** Wrapper ro getting twitter data with cache mechanism **/
    public function get_data($atts)
    {
      $username			           = ot_get_option('twitter_username');
      $data_store = 'codepages-twitter-' . $username;
      $back_store = 'codepages-twitter-da-' . $username;
      $cache_time = 60 * 10;
      if (($data = get_transient($data_store)) === false) {
        $data = $this->get_twitter_data($atts);
        if ($data) {
          // save a transient to expire in $cache_time and a permanent backup option ( fallback )
          set_transient($data_store, $data, $cache_time);
          update_option($back_store, $data);
        } // fall to permanent backup store
        else {
          $data = get_option($back_store);
        }
      }
      return $data;
    }

    /** Generates HTML code for each Tweet **/

    public function get_li($tweet, $atts) {
    	$html = '<li>';
    	$html .= '<a class="username" ' . (isset($atts['open_new_page'])  && 'on' == $atts['open_new_page'] ? 'target="_blank"' : '') . ' href="http://twitter.com/' . $tweet->user->screen_name . '">';
    	$html .= '<span class="username">@' . $tweet->user->name . '</span></a>';
    	$html .=  $tweet->text;
    	$html .= '<div class="date">' . date('M d Y', strtotime($tweet->created_at)) . '</div>';
    	$html .= '</li>';
    	return $html;
    }
  } // end class
} // end if
