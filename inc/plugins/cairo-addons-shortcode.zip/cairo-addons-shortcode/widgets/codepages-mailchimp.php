<?php

// ==========================================================================================
// Codepages Mailchimp Widget
// ==========================================================================================

add_action( 'widgets_init', 'widget_mailchimp_widget' );
function widget_mailchimp_widget() {
	register_widget( 'Widget_Mailchimp' );
}
class Widget_Mailchimp extends WP_Widget {
	public function __construct() {
      $widget_ops = array(
        'classname'   => 'widget_mailchimp_container',
        'description' => esc_html_x( 'A short description about you.', 'Mailchimp widget description', 'cairo' )
      );
      $control_ops = array( 'id_base' => 'widget_mailchimp_widget' );
      parent::__construct( 'widget_mailchimp_widget', sprintf( esc_html_x( ':. %s - Mailchimp ', 'Mailchimp Subscribe widget name', 'cairo' ), CAIRO_THEME_NAME ), $widget_ops, $control_ops );
   }

	public function widget( $args, $instance ) {
		extract( $args );
		$title   					= apply_filters('widget_title', $instance['title'] );
		$layout 					= empty($instance['layout']) ? 'style1' : $instance['layout'];
		$title_subscribe 	= esc_attr($instance['title_subscribe']);
		$des_subscribe  	= esc_attr($instance['des_subscribe']);
		$form_id 					= esc_attr($instance['form_id']);

		echo wp_kses_post( $args['before_widget'] );

			if( !empty( $form_id ) ) :
				$formid = '[mc4wp_form id="' . esc_attr( $form_id ) . '"]';
				$formid_embed = do_shortcode( $formid );
			else:
				$formid = "";
			endif;
			?>

			<div class="codepages-newsletter codepages-newsletter-widget  codepages-newsletter-<?php echo $layout;?>">
				<span class="fa fa-envelope newsletter-icon"></span>
				<div class="newsletter-widget-content">
					<h3><?php echo $title_subscribe;?></h3>
					<p><?php echo $des_subscribe;?></p>
				</div>
				<div class="newsletter-widget-embed">
					<?php echo $formid_embed;?>
				</div>
			</div>

			<?php echo wp_kses_post( $args['after_widget'] );
	}

	public function update( $new_instance, $old_instance ) {
		$instance             				= $old_instance;
		$instance['layout']   				= strip_tags( $new_instance['layout'] );
		$instance['title']    				= strip_tags( $new_instance['title'] );
		$instance['title_subscribe'] 	= $new_instance['title_subscribe'];
		$instance['des_subscribe']  	= $new_instance['des_subscribe'];
		$instance['form_id'] 					= $new_instance['form_id'];
		return $instance;
	}

	public function form( $instance ) {
		$defaults 						= array( 'title' => 'Mailchimp' );
		$instance 					= wp_parse_args( (array) $instance, $defaults );
		$mailchimp_layout   = isset( $instance['layout'] ) ? ( $instance['layout'] ) : 'blocks'; ?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"><?php esc_html_e( 'Layout Mailchimp :', 'cairo' ) ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'layout' ) ); ?>">
				<option value="style1"<?php echo ( $mailchimp_layout == 'style1' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Style 1', 'cairo' ) ?></option>
				<option value="style2"<?php echo ( $mailchimp_layout == 'style2' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Style 2', 'cairo' ) ?></option>
			</select>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title :', 'cairo' ); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo (isset($instance['title'])?esc_attr($instance['title']):""); ?>" class="widefat" type="text">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'form_id' ); ?>"><?php esc_html_e( 'Form ID Subscribe', 'cairo' ); ?></label>
			<input id="<?php echo $this->get_field_id( 'form_id' ); ?>" name="<?php echo $this->get_field_name( 'form_id' ); ?>" value="<?php echo (isset($instance['form_id'])?esc_attr($instance['form_id']):""); ?>" class="widefat" type="text">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'title_subscribe' ); ?>"><?php esc_html_e( 'Title Subscribe', 'cairo' ); ?></label>
			<input id="<?php echo $this->get_field_id( 'title_subscribe' ); ?>" name="<?php echo $this->get_field_name( 'title_subscribe' ); ?>" value="<?php echo (isset($instance['title_subscribe'])?esc_attr($instance['title_subscribe']):""); ?>" class="widefat" type="text">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'des_subscribe' ); ?>"><?php esc_html_e( 'Description Subscribe', 'cairo' ); ?></label>
			<textarea id="<?php echo $this->get_field_id( 'des_subscribe' ); ?>" name="<?php echo $this->get_field_name( 'des_subscribe' ); ?>" class="widefat"><?php echo (isset($instance['des_subscribe'])?esc_attr($instance['des_subscribe']):""); ?></textarea>
		</p>
	<?php
	}
}
