<?php
// ==========================================================================================
// Codepages Tap Posts Widget
// ==========================================================================================

add_action( 'widgets_init', 'widget_tap_post' );
function widget_tap_post() {
	register_widget( 'Widget_tap_posts' );
}
class Widget_tap_posts extends WP_Widget {
	public function __construct() {
			$widget_ops = array(
				'classname'   => 'widget_tap_post',
				'description' => esc_html_x( 'A short description about you.', 'Tag Cloud widget description', 'codepages' )
			);
			$control_ops = array( 'id_base' => 'widget_tap_post' );
			parent::__construct( 'widget_tap_post', sprintf( esc_html_x( ':. %s - Tap Posts', 'Tap Posts widget name', 'codepages' ), CAIRO_THEME_NAME ), $widget_ops, $control_ops );
	 }

	/**
	 * How to display the widget on the screen.
	 */
	public function widget( $args, $instance ) {
		extract( $args );

		/* Our variables from the widget settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		$tabtitle1 = $instance['tabtitle1'];
		$categories1 = $instance['categories1'];
		$selpost1 = $instance['selpost1'];
		$number1 = $instance['number1'];

		$tabtitle2 = $instance['tabtitle2'];
		$categories2 = $instance['categories2'];
		$selpost2 = $instance['selpost2'];
		$number2 = $instance['number2'];

		$tabtitle3 = $instance['tabtitle3'];
		$categories3 = $instance['categories3'];
		$selpost3 = $instance['selpost3'];
		$number3 = $instance['number3'];


		/* Before widget (defined by themes). */
		echo wp_kses_post( $before_widget );
		/* Display the widget title if one was input (before and after defined by themes). */
		if ( $title )
			echo ( $title != '' ? wp_kses_post( $before_title . $title . $after_title ) : '' );

			$widg_id = $args['widget_id'] . '-' . cairo_id_static();

		?>
		<!--Tab for Recent Post and Popular Post-->
		<div class="cairo-posts-tap-widgets">
			<div class="widget-content">
				<ul class="nav nav-tabs" role="tablist">
				<?php if ( ! empty( $instance['tabtitle1'] ) ): ?>
					<li role="presentation" class="active"><a href="#tab1_<?php echo esc_attr( $widg_id ); ?>" aria-controls="tab1_<?php echo esc_attr( $widg_id ); ?>" role="tab" data-toggle="tab"><?php echo esc_attr( $tabtitle1 );?></a></li>
				<?php endif; ?>
				<?php if ( ! empty( $instance['tabtitle2'] ) ): ?>
					<li role="presentation"><a href="#tab2_<?php echo esc_attr( $widg_id ); ?>" aria-controls="tab2_<?php echo esc_attr( $widg_id ); ?>" role="tab" data-toggle="tab"><?php echo esc_attr( $tabtitle2 );?></a></li>
				<?php endif; ?>
				<?php if ( ! empty( $instance['tabtitle3'] ) ): ?>
					<li role="presentation"><a href="#tab3_<?php echo esc_attr( $widg_id ); ?>" aria-controls="tab3_<?php echo esc_attr( $widg_id ); ?>" role="tab" data-toggle="tab"><?php echo esc_attr( $tabtitle3 );?></a></li>
				<?php endif; ?>
				</ul>

				<!-- Recent Post -->
				<div class="tab-content">
					<div role="tabpanel" class="tab-pane active fade in" id="tab1_<?php echo esc_attr( $widg_id ); ?>">
						<?php
							if($selpost1 == 'recent'){
								$query = array('posts_per_page' => $number1 ? $number1 : 3, 'orderby' => 'date', 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'cat' => $categories1);
								$output = $this->TabPostOutput($query);
							}elseif($selpost1 == 'random'){
								$query = array( 'posts_per_page' => $number1 ? $number1 : 3, 'orderby' => 'rand', 'order' => 'DESC', 'cat' => $categories1  );
								$output = $this->TabPostOutput($query);
							}elseif($selpost1 == 'comments'){
								$query = array( 'posts_per_page' => $number1 ? $number1 : 3, 'orderby' => 'comment_count', 'order' => 'DESC', 'cat' => $categories1  );
								$output = $this->TabPostOutput($query);
							}
							echo ''.$output;
						?>
					</div>

					<div role="tabpanel" class="tab-pane fade" id="tab2_<?php echo esc_attr( $widg_id ); ?>">
						<?php
							if($selpost2 == 'recent'){
								$query = array('posts_per_page' => $number2 ? $number2 : 3, 'orderby' => 'date', 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'cat' => $categories2);
								$output = $this->TabPostOutput($query);
							}elseif($selpost2 == 'random'){
								$query = array( 'posts_per_page' => $number2 ? $number2 : 3, 'orderby' => 'rand', 'order' => 'DESC', 'cat' => $categories2  );
								$output = $this->TabPostOutput($query);
							}elseif($selpost2 == 'comments'){
								$query = array( 'posts_per_page' => $number2 ? $number2 : 3, 'orderby' => 'comment_count', 'order' => 'DESC', 'cat' => $categories2  );
								$output = $this->TabPostOutput($query);
							}
							echo ''.$output;
						?>
					</div>

					<div role="tabpanel" class="tab-pane fade" id="tab3_<?php echo esc_attr( $widg_id ); ?>">
						<?php
							if($selpost3 == 'recent'){
								$query = array('posts_per_page' => $number3 ? $number3 : 3, 'orderby' => 'date', 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'cat' => $categories3);
								$output = $this->TabPostOutput($query);
							}elseif($selpost3 == 'random'){
								$query = array( 'posts_per_page' => $number3 ? $number3 : 3, 'orderby' => 'rand', 'order' => 'DESC', 'cat' => $categories3  );
								$output = $this->TabPostOutput($query);
							}elseif($selpost3 == 'comments'){
								$query = array( 'posts_per_page' => $number3 ? $number3 : 3, 'orderby' => 'comment_count', 'order' => 'DESC', 'cat' => $categories3  );
								$output = $this->TabPostOutput($query);
							}
							echo ''.$output;
						?>
					</div>
				</div>
			</div>
		</div>

		<?php

		/* After widget (defined by themes). */
		echo wp_kses_post( $after_widget );
	}

	public function TabPostOutput($query){ ?>
			<?php $loop = new WP_Query($query);
			if ($loop->have_posts()) {
				while ($loop->have_posts()) {
					$loop->the_post(); ?>
					<?php $cairo_views = cairo_get_post_views(get_the_ID()); ?>
					<div class="cairo-posts-widgets-style1 posts-block-layout">
						<div class="post-image">
							<?php if ( has_post_thumbnail() ) { ?>
							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
								<?php the_post_thumbnail('cairo-post-thumb-three', array()); ?>
							</a>
							<?php } ?>
						</div>
						<div class="post-details">
							<div class="post-title">
								<?php the_title('<h5 class="entry-title"><a href="'.get_permalink().'" title="'.the_title_attribute("echo=0").'">', '</a></h5>'); ?>
							</div>
							<ul class="post-meta no-sep">
								<li class="post-data"><i class="fa fa-clock-o"></i><?php the_time( get_option('date_format') ); ?></li>
								<li class="post-data"><i class="fa fa-eye"></i><?php echo ($cairo_views); ?> <?php echo esc_html__('Views', 'cairo'); ?></li>
							</ul>
						</div>
					</div>
				<?php } //while
			wp_reset_postdata();
		} //if ?>
	<?php }

	public function advanceTabWidgetCommentsOutput($args){
		if( !function_exists( 'comment_custom_excerpt_length' ) ){
			function comment_custom_excerpt_length( $length ) {
				return 3;
			}
		}
		add_filter( 'comment_excerpt_length', 'comment_custom_excerpt_length', 999 );

		$comments = get_comments( apply_filters( 'widget_comments_args', $args ) );
		$output = '<ul id="recentcomments">';
		if ( is_array( $comments ) && $comments ) {

			foreach ( (array) $comments as $comment ) {
				$output .= '<li class="recentcomments">';
				/* translators: comments widget: 1: comment author, 2: post link */
				$output .= '<a href="' . esc_url( get_comment_link( $comment ) ) . '">' . get_the_title( $comment->comment_post_ID ) . '</a> #'.  get_comment_excerpt($comment).' '. esc_html__('by', 'cairo') .' <span class="comment-author-link"><i>' . get_comment_author_link( $comment ) . '</i></span>' ;
				$output .= '</li>';
			}
		}
		$output .= '</ul>';

		return $output;
	}

	/**
	 * Update the widget settings.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );

		$instance['tabtitle1'] = $new_instance['tabtitle1'];
		$instance['categories1'] = strip_tags( $new_instance['categories1'] );
		$instance['selpost1'] = strip_tags( $new_instance['selpost1'] );
		$instance['number1'] = strip_tags( $new_instance['number1'] );

		$instance['tabtitle2'] = $new_instance['tabtitle2'];
		$instance['categories2'] = strip_tags( $new_instance['categories2'] );
		$instance['selpost2'] = strip_tags( $new_instance['selpost2'] );
		$instance['number2'] = strip_tags( $new_instance['number2'] );

		$instance['tabtitle3'] = $new_instance['tabtitle3'];
		$instance['categories3'] = strip_tags( $new_instance['categories3'] );
		$instance['selpost3'] = strip_tags( $new_instance['selpost3'] );
		$instance['number3'] = strip_tags( $new_instance['number3'] );

		return $instance;
	}


	public function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 'title' => '', 'tabtitle1' => '', 'categories1' => 'all', 'selpost1' => 'recent', 'number1' => '', 'tabtitle2' => '', 'categories2' => 'all', 'selpost2' => 'recent', 'number2' => '', 'tabtitle3' => '', 'categories3' => 'all', 'selpost3' => 'recent', 'number3' => '');
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- First TAB title -->
		<p><h4><u><?php esc_html_e('First Tab Settings:', 'cairo'); ?></u></h4></p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'tabtitle1' ) ); ?>"><?php esc_html_e('First Tab Title:', 'cairo'); ?></label>
			<input  type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tabtitle1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tabtitle1' ) ); ?>" value="<?php echo esc_attr( $instance['tabtitle1'] ); ?>"  />
		</p>

		<!-- Category -->
		<?php $display = ''; if( $instance['selpost1'] != 'comments' ){ $display = 'block'; } else{ $display = 'none'; } ?>
		<p id="hs<?php echo esc_attr( $this->get_field_id('categories1') ); ?>" style="display:<?php echo esc_attr( $display ); ?>;">
		<label for="<?php echo esc_attr( $this->get_field_id('categories1') ); ?>"><?php esc_html_e('Filter by Category:', 'cairo'); ?></label>
		<select id="<?php echo esc_attr( $this->get_field_id('categories1') ); ?>" name="<?php echo esc_attr( $this->get_field_name('categories1') ); ?>" class="widefat categories" style="width:100%;">
			<option value='all' <?php if ('all' == $instance['categories1']) echo 'selected="selected"'; ?>><?php esc_html_e('All categories', 'cairo'); ?></option>
			<?php $categories = get_categories('hide_empty=1&depth=1&type=post'); ?>
			<?php foreach($categories as $category) { ?>
			<option value='<?php echo esc_attr( $category->term_id ); ?>' <?php if ($category->term_id == $instance['categories1']) echo 'selected="selected"'; ?>><?php echo esc_attr( $category->cat_name ); ?></option>
			<?php } ?>
		</select>
		</p>

		<!-- Select Post (Recent, Popular ...) -->
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id('selpost1') ); ?>"><?php esc_html_e('Select Post Type:', 'cairo'); ?></label>
		<select id="<?php echo esc_attr( $this->get_field_id('selpost1') ); ?>" name="<?php echo esc_attr( $this->get_field_name('selpost1') ); ?>" class="widefat advance_widget_posttab_selpost" style="width:100%;">
			<?php
				$postviews = array(
					"recent"=> esc_html__( 'Recent Posts', 'cairo' ),
					"random"=> esc_html__( 'Random Posts', 'cairo' ),
					"comments"=> esc_html__( 'Post Comments', 'cairo' )
				);
			?>
			<?php foreach($postviews as $pkey => $pval) { ?>
				<option value='<?php echo esc_attr( $pkey ); ?>' <?php if ($pkey == $instance['selpost1']) echo 'selected="selected"'; ?>><?php echo esc_attr( $pval ); ?></option>
			<?php } ?>
		</select>
		</p>

		<!-- Number of posts/comments -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number1' ) ); ?>"><?php esc_html_e('Number of Recent posts/comments to show:', 'cairo'); ?></label>
			<input  type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number1' ) ); ?>" value="<?php echo esc_attr( $instance['number1'] ); ?>" size="3" />
		</p>

		<!-- Second TAB title -->
		<p><h4><u><?php esc_html_e('Second Tab Settings:', 'cairo'); ?></u></h4></p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'tabtitle2' ) ); ?>"><?php esc_html_e('Second Tab Title:', 'cairo'); ?></label>
			<input  type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tabtitle2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tabtitle2' ) ); ?>" value="<?php echo esc_attr( $instance['tabtitle2'] ); ?>"  />
		</p>

		<!-- Category -->
		<?php $display = ''; if( $instance['selpost2'] != 'comments' ){ $display = 'block'; } else{ $display = 'none'; } ?>
		<p id="hs<?php echo esc_attr( $this->get_field_id('categories2') ); ?>" style="display:<?php echo esc_attr( $display ); ?>;">
		<label for="<?php echo esc_attr( $this->get_field_id('categories2') ); ?>"><?php esc_html_e('Filter by Category:', 'cairo'); ?></label>
		<select id="<?php echo esc_attr( $this->get_field_id('categories2') ); ?>" name="<?php echo esc_attr( $this->get_field_name('categories2') ); ?>" class="widefat categories" style="width:100%;">
			<option value='all' <?php if ('all' == $instance['categories2']) echo 'selected="selected"'; ?>><?php esc_html_e('All categories', 'cairo'); ?></option>
			<?php $categories = get_categories('hide_empty=1&depth=1&type=post'); ?>
			<?php foreach($categories as $category) { ?>
			<option value='<?php echo esc_attr( $category->term_id ); ?>' <?php if ($category->term_id == $instance['categories2']) echo 'selected="selected"'; ?>><?php echo esc_attr( $category->cat_name ); ?></option>
			<?php } ?>
		</select>
		</p>

		<!-- Select Post (Recent, Popular ...) -->
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id('selpost2') ); ?>"><?php esc_html_e('Select Post Type:', 'cairo'); ?></label>
		<select id="<?php echo esc_attr( $this->get_field_id('selpost2') ); ?>" name="<?php echo esc_attr( $this->get_field_name('selpost2') ); ?>" class="widefat advance_widget_posttab_selpost" style="width:100%;">
			<?php
				$postviews = array(
					"recent"=> esc_html__( 'Recent Posts', 'cairo' ),
					"random"=> esc_html__( 'Random Posts', 'cairo' ),
					"comments"=> esc_html__( 'Post Comments', 'cairo' )
				);
			?>
			<?php foreach($postviews as $pkey => $pval) { ?>
				<option value='<?php echo esc_attr( $pkey ); ?>' <?php if ($pkey == $instance['selpost2']) echo 'selected="selected"'; ?>><?php echo esc_attr( $pval ); ?></option>
			<?php } ?>
		</select>
		</p>

		<!-- Number of posts/comments -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number2' ) ); ?>"><?php esc_html_e('Number of Recent posts/comments to show:', 'cairo'); ?></label>
			<input  type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number2' ) ); ?>" value="<?php echo esc_attr( $instance['number2'] ); ?>" size="3" />
		</p>

		<!-- Thrid TAB title -->
		<p><h4><u><?php esc_html_e('Thrid Tab Settings:', 'cairo'); ?></u></h4></p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'tabtitle3' ) ); ?>"><?php esc_html_e('Thrid Tab Title:', 'cairo'); ?></label>
			<input  type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tabtitle3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tabtitle3' ) ); ?>" value="<?php echo esc_attr( $instance['tabtitle3'] ); ?>"  />
		</p>

		<!-- Category -->
		<?php $display = ''; if( $instance['selpost3'] != 'comments' ){ $display = 'block'; } else{ $display = 'none'; } ?>
		<p id="hs<?php echo esc_attr( $this->get_field_id('categories3') ); ?>" style="display:<?php echo esc_attr( $display ); ?>;">
		<label for="<?php echo esc_attr( $this->get_field_id('categories3') ); ?>"><?php esc_html_e('Filter by Category:', 'cairo'); ?></label>
		<select id="<?php echo esc_attr( $this->get_field_id('categories3') ); ?>" name="<?php echo esc_attr( $this->get_field_name('categories3') ); ?>" class="widefat categories" style="width:100%;">
			<option value='all' <?php if ('all' == $instance['categories3']) echo 'selected="selected"'; ?>><?php esc_html_e('All categories', 'cairo'); ?></option>
			<?php $categories = get_categories('hide_empty=1&depth=1&type=post'); ?>
			<?php foreach($categories as $category) { ?>
			<option value='<?php echo esc_attr( $category->term_id ); ?>' <?php if ($category->term_id == $instance['categories3']) echo 'selected="selected"'; ?>><?php echo esc_attr( $category->cat_name ); ?></option>
			<?php } ?>
		</select>
		</p>

		<!-- Select Post (Recent, Popular ...) -->
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id('selpost3') ); ?>"><?php esc_html_e('Select Post Type:', 'cairo'); ?></label>
		<select id="<?php echo esc_attr( $this->get_field_id('selpost3') ); ?>" name="<?php echo esc_attr( $this->get_field_name('selpost3') ); ?>" class="widefat advance_widget_posttab_selpost" style="width:100%;">
			<?php
				$postviews = array(
					"recent"=> esc_html__( 'Recent Posts', 'cairo' ),
					"random"=> esc_html__( 'Random Posts', 'cairo' ),
					"comments"=> esc_html__( 'Post Comments', 'cairo' )
				);
			?>
			<?php foreach($postviews as $pkey => $pval) { ?>
				<option value='<?php echo esc_attr( $pkey ); ?>' <?php if ($pkey == $instance['selpost3']) echo 'selected="selected"'; ?>><?php echo esc_attr( $pval ); ?></option>
			<?php } ?>
		</select>
		</p>

		<!-- Number of posts/comments -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number3' ) ); ?>"><?php esc_html_e('Number of Recent posts/comments to show:', 'cairo'); ?></label>
			<input  type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number3' ) ); ?>" value="<?php echo esc_attr( $instance['number3'] ); ?>" size="3" />
		</p>
		<!--This Script for display some fields enable disable-->
		<script type="text/javascript">
			jQuery(function() {
				jQuery( ".advance_widget_posttab_selpost" ).change(function() {
					var thisid = jQuery(this).attr('id');
					thisid = thisid.replace('selpost','categories');
					var option = jQuery(this).find('option:selected').val();
					if(option == 'comments'){
						jQuery('#hs'+thisid).hide();
					}else{
						jQuery('#hs'+thisid).show();
					}
				});
			});
		</script>


	<?php
	}
}

?>
