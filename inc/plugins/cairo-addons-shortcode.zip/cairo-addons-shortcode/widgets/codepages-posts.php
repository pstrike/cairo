<?php
// ==========================================================================================
// Codepages Posts Slider Widget
// ==========================================================================================

add_action( 'widgets_init', 'cairo_widget_category_posts' );
function cairo_widget_category_posts() {
	register_widget( 'cairo_category_posts_widget' );
}
class cairo_category_posts_widget extends WP_Widget {
	public function __construct() {
		$widget_ops = array(
			'classname'   => 'cairo-widget-category-posts',
			'description' => esc_html_x( 'Displays the posts with more stylish way', 'Category Posts widget description', 'cairo' )
		);
		parent::__construct( 'cairo-category-posts', sprintf( esc_html_x( '.: %s - Posts', 'Posts widget name', 'cairo' ), CAIRO_THEME_NAME ), $widget_ops );
		add_action( 'save_post', array($this, 'flush_widget_cache') );
		add_action( 'deleted_post', array($this, 'flush_widget_cache') );
		add_action( 'switch_theme', array($this, 'flush_widget_cache') );
	}

	public function widget( $args, $instance ) {
		$cairo_cache = array();
		if ( ! $this->is_preview() ) {
			$cairo_cache = wp_cache_get( 'cairo-category-posts', 'widget' );
		}
		if ( ! is_array( $cairo_cache ) ) {
			$cairo_cache = array();
		}
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}
		if ( isset( $cairo_cache[ $args['widget_id'] ] ) ) {
			echo wp_kses_post( $cairo_cache[ $args['widget_id'] ] );
			return;
		}
		ob_start();

		$cairo_params = array(
			'no_found_rows'         => true,
			'post_status'           => 'publish',
			'ignore_sticky_posts'   => true
		);

		if ( empty( $instance['number'] ) || ! $cairo_params['posts_per_page'] = absint( $instance['number'] ) ) {
			$cairo_params['posts_per_page'] = 5;
		}

		if ( ! empty( $instance['category'] ) ) {
			$cairo_params['cat'] = $instance['category'];
		}

		$layout = empty($instance['layout']) ? 'style1' : $instance['layout'];

		switch ( $instance['orderby'] ) {
			case 'views':
				$cairo_params['orderby'] = 'meta_value_num';
				$cairo_params['meta_key'] = 'post_views_count';
				break;
			case 'comments':
				$cairo_params['orderby'] = 'comment_count';
				break;
			case 'random':
				$cairo_params['orderby'] = 'rand';
				break;
			case 'posts':
				$cairo_params['orderby'] = 'post__in';
				break;
			default:
				$cairo_params['orderby'] = 'date';
		}

		$cairo_params['order'] = ( $instance['order'] != 'asc' ) ? 'DESC' : 'ASC';

		$cairo_query = new WP_Query( $cairo_params );

		if ( $cairo_query->have_posts() ):
			echo wp_kses_post( $args['before_widget'] );
			if ( ! empty( $instance['title'] ) ) {
				echo wp_kses_post( $args['before_title'] ) . esc_html( $instance['title'] ) . wp_kses_post( $args['after_title'] );
		}?>

		<div class="cairo-posts-category cairo-posts-category-widget">
			<?php if($layout == 'style1'): ?>
				<?php while ( $cairo_query->have_posts() ) : $cairo_query->the_post(); ?>
				<?php $cairo_views = cairo_get_post_views(get_the_ID()); ?>
				<div class="cairo-posts-widgets-style1 posts-block-layout">
					<div class="post-image">
						<?php if ( has_post_thumbnail() ) { ?>
						<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
							<?php the_post_thumbnail('cairo-post-thumb-three', array()); ?>
						</a>
						<?php } ?>
					</div>
					<div class="post-details">
						<div class="post-title">
							<?php the_title('<h5 class="entry-title"><a href="'.get_permalink().'" title="'.the_title_attribute("echo=0").'">', '</a></h5>'); ?>
						</div>
						<ul class="post-meta no-sep">
							<li class="post-data"><i class="fa fa-clock-o"></i><?php the_time( get_option('date_format') ); ?></li>
							<li class="post-data"><i class="fa fa-eye"></i><?php echo ($cairo_views); ?> <?php echo esc_html__('Views', 'cairo'); ?></li>
						</ul>
					</div>
				</div>
				<?php endwhile; ?>
			<?php else: $i = 0; ?>
				<?php while ( $cairo_query->have_posts() ) : $cairo_query->the_post(); ?>
				<?php $cairo_views = cairo_get_post_views(get_the_ID()); ?>
				<div class="cairo-posts-widgets-style2 posts-block-layout">
					<?php if( $i == 1) { ?>
						<div class="post-image">
						<?php if ( has_post_thumbnail() ) { ?>
						<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
							<?php the_post_thumbnail('cairo-post-humb-one', array()); ?>
						</a>
						<?php } ?>
						</div>
					<?php } else {} ?>
					<div class="post-details">
						<div class="post-title">
							<?php the_title('<h5 class="entry-title"><a href="'.get_permalink().'" title="'.the_title_attribute("echo=0").'">', '</a></h5>'); ?>
						</div>
						<ul class="post-meta no-sep">
							<li class="post-data"><i class="fa fa-clock-o"></i><?php the_time( get_option('date_format') ); ?></li>
							<li class="post-data"><i class="fa fa-eye"></i><?php echo ($cairo_views); ?> <?php echo esc_html__('Views', 'cairo'); ?></li>
						</ul>
					</div>
				</div>
				<?php endwhile; ?>
			<?php endif ?>
		</div>
		<?php
		echo wp_kses_post( $args['after_widget'] );
		wp_reset_postdata();
		endif;

		if ( ! $this->is_preview() ) {
			$cairo_cache[ $args['widget_id'] ] = ob_get_flush();
			wp_cache_set( 'cairo-category-posts', $cairo_cache, 'widget' );
		} else {
			ob_end_flush();
		}

	}

	public function flush_widget_cache() {
		wp_cache_delete( 'cairo-category-posts', 'widget' );
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']          = strip_tags( $new_instance['title'] );
		$instance['number']         = absint( $new_instance['number'] );
		$instance['category']       = $new_instance['category'];
		$instance['orderby']        = sanitize_key( $new_instance['orderby'] );
		$instance['order']          = sanitize_key( $new_instance['order'] );
		$instance['layout']         = strip_tags( $new_instance['layout'] );

		$this->flush_widget_cache();
		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset( $alloptions['cairo-category-posts'] ) ) {
			delete_option( 'cairo-category-posts' );
		}
		return $instance;
	}

	public function form( $instance ) {
		$cairo_title        = isset( $instance['title'] ) ? $instance['title'] : '';
		$cairo_number       = isset( $instance['number'] ) ? $instance['number'] : 5;
		$cairo_category     = isset( $instance['category'] ) ? intval( $instance['category'] ) : '';
		$cairo_orderby      = isset( $instance['orderby'] ) ? sanitize_key( $instance['orderby'] ) : 'date';
		$cairo_order        = isset( $instance['order'] ) ? sanitize_key( $instance['order'] ) : 'desc';
		$cairo_order        = isset( $instance['layout'] ) ? ( $instance['layout'] ) : 'style1';
		$cairo_categories = get_categories();
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'cairo' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $cairo_title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"><?php esc_html_e( 'Post Style :', 'cairo' ) ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'layout' ) ); ?>">
				<option value="style1"<?php echo ( $cairo_order == 'style1' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Style 1', 'cairo' ) ?></option>
				<option value="style2"<?php echo ( $cairo_order == 'style2' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Style 2', 'cairo' ) ?></option>
			</select>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>"><?php esc_html_e( 'Choose category:', 'cairo' ); ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'category' ) ); ?>">
				<option value=""><?php esc_html_e( '- All -', 'cairo' ); ?></option>
				<?php foreach ( $cairo_categories as $cairo_cat ): ?>
				<option value="<?php echo intval( $cairo_cat->term_id ); ?>"<?php echo ( $cairo_category == $cairo_cat->term_id ) ? ' selected' : ''; ?>><?php echo esc_html( $cairo_cat->name ) .' ('. intval( $cairo_cat->count ) .')'; ?></option>
				<?php endforeach; ?>
			</select>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'cairo' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo absint( $cairo_number ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'orderby' ) ); ?>"><?php esc_html_e( 'Order Posts by :', 'cairo' ) ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'orderby' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'orderby' ) ); ?>" class="cairo-select-post-orderby">
				<option value="date"<?php echo ( $cairo_orderby == 'date' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Date', 'cairo' ) ?></option>
				<option value="views"<?php echo ( $cairo_orderby == 'views' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Number of Views', 'cairo' ) ?></option>
				<option value="comments"<?php echo ( $cairo_orderby == 'comments' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Number of Comments', 'cairo' ) ?></option>
				<option value="random"<?php echo ( $cairo_orderby == 'random' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Random', 'cairo' ) ?></option>
				<option value="posts"<?php echo ( $cairo_orderby == 'posts' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Manual Post IDs', 'cairo' ) ?></option>
			</select>
		</p>

		<p class="cairo-post-order-type"<?php echo ( $cairo_orderby == 'random' ) ? ' style="display: none;' : ''; ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>"><?php esc_html_e( 'Order Type :', 'cairo' ) ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'order' ) ); ?>">
				<option value="desc"<?php echo ( $cairo_order == 'desc' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Descending', 'cairo' ) ?></option>
				<option value="asc"<?php echo ( $cairo_order == 'asc' ) ? ' selected' : ''; ?>><?php esc_html_e( 'Ascending', 'cairo' ) ?></option>
			</select>
		</p>
		<?php

	}

}
