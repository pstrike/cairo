<?php
/**
 *
 * Instagram Module
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_instagram( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'		          =>	'',
			'title_insta'				=>	'',
			'username_insta'		=>	'',
			'count_img'		      =>  '',
			'extra_class'				=>  '',
			'extra_id'					=>  '',
		), $atts
	);


	$output = '';

	$style 							= $atts['style'];
	$title_insta 				= $atts['title_insta'];
	$username 				  = $atts['username_insta'];
	$number         		= $atts['count_img'];
	$blockclass 				= $atts['extra_class'];
	$blockid    				= $atts['extra_id'];
	$media_array 				= scrape_instagram( $atts['username_insta'], $atts['count_img'] );

  // ==========================================================================================
  // Module Icon Bos Style
  // ==========================================================================================

	$output .= '<div class="codepages-instagram">';
	$output .= '<div class="codepages-instagram-wrapper">';
	$output .= '<h2 class="title-insta-block"><i class="fa fa-instagram"></i> '.$title_insta.' </h2>';
	foreach ( $media_array as $k => $d ) {
		$code = $d['code'];
		$output .= '<div class="'.$style.' col-sm-12 col-xs-12 none-padding">';
		$output .='
			<a href="https://instagram.com/p/'. $code .'/" target="_blank" rel="nofollow">
				<img src="'.preg_replace( '#\/s[0-9]+x[0-9]+\/#', '/s390x390/', $d['thumbnail_src'] ).'" class="trs" alt="" />
			</a>
		';
		$output .= '</div>';
	}
	$output .= '</div>';
	$output .= '</div>';
	return $output;

}
add_shortcode("codepages_instagram_module", "codepages_instagram");

function scrape_instagram( $username, $slice = 8 ) {
	$codepages_remote_url = esc_url( 'http://instagram.com/'. trim( strtolower( $username ) ) );
	$codepages_transient_key = 'cairo_instagram_feed_'. sanitize_title_with_dashes( $username );
	$slice = absint( $slice );
	if ( false === ( $codepages_result_data = get_transient( $codepages_transient_key ) ) ) {
		$codepages_remote = wp_remote_get( $codepages_remote_url );
		if ( is_wp_error( $codepages_remote ) || 200 != wp_remote_retrieve_response_code( $codepages_remote ) ) {
			return new WP_Error( 'not-connected', esc_html__( 'Unable to communicate with Instagram.', 'cairo' ) );
		}
		preg_match( '#window\.\_sharedData\s\=\s(.*?)\;\<\/script\>#', $codepages_remote['body'], $codepages_match );
		if ( ! empty( $codepages_match ) ) {
			$media_array = json_decode( end( $codepages_match ), true );
			if ( is_array( $media_array ) && isset ( $media_array['entry_data']['ProfilePage'][0]['user']['media']['nodes'] ) ) {
				$codepages_result_data = $media_array['entry_data']['ProfilePage'][0]['user']['media']['nodes'];
			}
		}
		if ( is_array( $codepages_result_data ) ) {
			set_transient( $codepages_transient_key, $codepages_result_data, 60 * 60 * 2 );
		}
	}
	if ( empty( $codepages_result_data ) ) {
		return new WP_Error( 'no-images', esc_html__( 'Instagram did not return any images.', 'cairo' ) );
	}
	return array_slice( $codepages_result_data, 0, $slice );
}
