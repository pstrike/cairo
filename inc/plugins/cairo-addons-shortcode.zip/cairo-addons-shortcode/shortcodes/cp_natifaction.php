<?php
/**
 *
 * Natifaction Box
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_alert( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'alert_type'				=>	'',
			'alert_text'				=>  '',
		), $atts
	);

	$output = '';

	$alert_type 			= $atts['alert_type'];
	$text 						= $atts['alert_text'];

	// ==========================================================================================
  // Module Natifaction Style
  // ==========================================================================================

	if( strstr( $atts['alert_type'], "success" ) ) :
  $output .='
	 <div class="alert alert-'.$alert_type.' alert-dismissable fade in">
	  <i class="fa fa-check"></i>
 		<span>'.$text.'</span>
	 </div>
	';
  elseif( strstr( $atts['alert_type'], "info" ) ) :
	$output .='
	 <div class="alert alert-'.$alert_type.' alert-dismissable fade in">
	  <i class="fa fa-info"></i>
 		<span>'.$text.'</span>
	 </div>
	';
  elseif( strstr( $atts['alert_type'], "warning" ) ) :
	$output .='
	 <div class="alert alert-'.$alert_type.' alert-dismissable fade in">
	  <i class="fa fa-warning"></i>
 		<span>'.$text.'</span>
	 </div>
	';
  elseif( strstr( $atts['alert_type'], "danger" ) ) :
	$output .='
	 <div class="alert alert-'.$alert_type.' alert-dismissable fade in">
	  <i class="fa fa-close"></i>
 		<span>'.$text.'</span>
	 </div>
	';
	else:
  endif;


	return $output;

}
add_shortcode("codepages_alert_module", "codepages_alert");
