<?php
/**
 *
 * Subscribe Module
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_subscribe_mailchimp( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'								=>	'',
			'title_text'					=>  '',
			'description_text'		=>  '',
			'formid'							=>  '',
			'lightordark'					=>  '',
		), $atts
	);

	$output = '';

	$style      				= $atts['style'];
	$title 							= $atts['title_text'];
	$description     	  = $atts['description_text'];
	$lightordark 				= $atts['lightordark'];

	if( !empty( $atts['formid'] ) ) :
		$formid = '[mc4wp_form id="' . esc_attr( $atts['formid'] ) . '"]';
		$formid_embed = do_shortcode( $formid );
	else:
		$formid = "";
	endif;

  // ==========================================================================================
  // Module Icon Bos Style
  // ==========================================================================================

	$output .= '<div class="codepages-subscribe codepages-subscribe-'.$style.' '.$lightordark.'">';
	$output .= '<div class="codepages-subscribe-wrapper">';
		$output .= '
		<h2 class="title-subscribe">'.$title.'</h2>
		<p class="description-subscribe">'.$description.'</p>
		';
	$output .= '</div>';

	$output .= '
		<div class="codepages_form_subscribe">
			'.$formid_embed.'
		</div>
	';
	$output .= '</div>';
	return $output;

}
add_shortcode("codepages_subscribe_mailchimp_module", "codepages_subscribe_mailchimp");
