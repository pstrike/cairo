<?php
/**
 *
 * Video Posts Box
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_video_posts( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'							=>	'',
			'source'						=>  '',
			'darkorlight'				=>  '',
			'playlisttitle'			=>  '',
			'cat'								=>	'',
			'postid'						=>	'',
			'tagslugs'					=>	'',
			'authorids'					=>	'',
			'postcount'					=>	'',
			'videoorderby'			=>	'',
			'excludeposts'			=>  '',
			'excludecategory'		=>  '',
			'excludetag'		  	=>  '',
		), $atts
	);

	$output = '';

  //Start Exclude category
	if( !empty( $atts['excludeposts'] ) ) :
		$excludepost = $atts['excludeposts'];
		$excludepost = explode( ',', $excludepost );
	else:
		$excludepost = "";
	endif;

	//Start Count Posts
	if( !empty( $atts['postcount'] ) ) :
		$postcount = $atts['postcount'];
	else:
		$postcount = "";
	endif;

	//Start Exclude Categoy
	if( !empty( $atts['excludecategory'] ) ) :
		$excludecategoy = $atts['excludecategory'];
		$excludecategoy = explode( ',', $excludecategoy );
	else:
		$excludecategoy = "";
	endif;

	//Start Exclude Tag
	if( !empty( $atts['excludetag'] ) ) :
		$excludetags = $atts['excludetag'];
		$excludetags = explode( ',', $excludetags );
	else:
		$excludetags = "";
	endif;

	//Start ID Posts
	if( !empty( $atts['postid'] ) ) :
		$bypostid = $atts['postid'];
		$bypostid = explode( ',', $bypostid );
	else:
		$bypostid = "";
	endif;

	//Start Category Order By
	if( !empty( $atts['videoorderby'] ) ) :
		$videoorderby = $atts['videoorderby'];
	else:
		$videoorderby = "";
	endif;

	//Start Dark Or Light
	if ($atts['darkorlight']=='dark') {
		$videostyle = 'video_dark';
	}
	elseif ($atts['darkorlight']=='light') {
		$videostyle = 'video_light';
	}

	// ==========================================================================================
  // Video Format Posts Style 1
  // ==========================================================================================

	if( strstr( $atts['style'], "style1" ) ) :

 		$output .= '<div class="video_posts_playlist video_playlist_style1 '.$videostyle.'" data-style="style-1" data-video-style="'.$videostyle.'">';

		$output .= '<div class="video_playlist_title">';
		//Start Section Title
		$playlisttitle = $atts['playlisttitle'];
		if( !empty($playlisttitle) ) :
			$output .= '<h3>'.$playlisttitle.'</h3>';
		else:
		endif;
		$output .= '</div>';

		//Start Query Breaking Posts
		$video_posts = array(
			'author'								=> $atts['authorids'],
			'posts_per_page' 				=> $postcount,
			'post_status'						=> 'publish',
			'ignore_sticky_posts'		=> 1,
			'tax_query' => array(
		    array(
	        'taxonomy' => 'post_format',
	        'field' => 'slug',
	        'terms' => array('post-format-video'),
		    )
			),
			'orderby'  				    	=> $videoorderby,
			'cat' 									=> $atts['cat'],
			'post__not_in' 					=> $excludepost,
			'category__not_in' 			=> $excludecategoy,
			'tag__not_in'						=> $excludetags,
			'post_type' 						=> 'post'
		);

		//Start Query
		$wp_query_args_video_posts = new WP_Query( $video_posts );
		if ($wp_query_args_video_posts->have_posts()) : $i=0; while ( $wp_query_args_video_posts->have_posts() ) : $wp_query_args_video_posts->the_post(); $i++;

		global $wp_embed;
		$embed = get_post_meta(get_the_ID(), 'post_video', TRUE);
		$embed_url = $wp_embed->run_shortcode('[embed]'.$embed.'[/embed]');


		if($i == 1) {
			$output .= '
			<div class="video-wrapper-playlist col-md-12 col-sm-12 col-xs-12">
			<div class="loading-posts"></div>
				<div class="video-wrapper">
				'.$embed_url.'
				</div>
			</div>
			';
		}

		//Start Loop Breaking News Post
		endwhile;
		endif;
		wp_reset_postdata();

		if ($wp_query_args_video_posts->have_posts()) : $i=0; while ( $wp_query_args_video_posts->have_posts() ) : $wp_query_args_video_posts->the_post(); $i++;

		//Start Category Content
		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();
		$postClass = join( ' ',get_post_class() );

		$post_meta_small = '
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		';

		$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-four' );
		$image = '<figure class="post-image">';
		$image .= '<img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" />';
		$image .= '</figure>';

		if($i == 1) {
			$output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="row"><div class="video-playlist">';
		}

		$output .= '
			<article class="post post-overlay post-video-playlist col-md-3 col-sm-12 col-xs-12">
				<div class="video-slider">
					<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '" id="'.get_the_ID().'">
						'. $image . '
						<div class="post-meta-box">
							<ul class="post-meta no-sep">
								'.$post_meta_small.'
							</ul>
						</div>
						<div class="post-title">
							<h6>'. get_the_title() .'</h6>
						</div>
					</a>
				</div>
			</article>
		';


		//Start Loop Breaking News Post
    endwhile;
		endif;
		wp_reset_postdata();
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Video Format Posts Style 2
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style2" ) ) :

		$output .= '<div class="video_posts_playlist video_playlist_style2 '.$videostyle.'" data-style="style-2" data-video-style="'.$videostyle.'">';
		$output .= '<div class="row">';

		$output .= '<div class="col-md-12 col-sm-12 col-xs-12">';
		$output .= '<div class="video_playlist_title">';
		//Start Section Title
		$playlisttitle = $atts['playlisttitle'];
		if( !empty($playlisttitle) ) :
			$output .= '<h3>'.$playlisttitle.'</h3>';
		else:
		endif;
		$output .= '</div>';
		$output .= '</div>';

		//Start Query Breaking Posts
		$video_posts = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['authorids'],
			'posts_per_page' 				=> $postcount,
			'post_status'						=> 'publish',
			'ignore_sticky_posts'		=> 1,
			'tax_query' => array(
		    array(
	        'taxonomy' => 'post_format',
	        'field' => 'slug',
	        'terms' => array('post-format-video'),
		    )
			),
			'orderby'  				    	=> $videoorderby,
			'cat' 									=> $atts['cat'],
			'post__not_in' 					=> $excludepost,
			'category__not_in' 			=> $excludecategoy,
			'tag__not_in'						=> $excludetags,
			'post_type' 						=> 'post'
		);

		//Start Query
		$wp_query_args_video_posts = new WP_Query( $video_posts );
		if ($wp_query_args_video_posts->have_posts()) : $i=0; while ( $wp_query_args_video_posts->have_posts() ) : $wp_query_args_video_posts->the_post(); $i++;

		global $wp_embed;
		$embed = get_post_meta(get_the_ID(), 'post_video', TRUE);
		$embed_url = $wp_embed->run_shortcode('[embed]'.$embed.'[/embed]');


		if($i == 1) {
			$output .= '
			<div class="video-wrapper-playlist col-md-8 col-sm-12 col-xs-12">
				<div class="loading-posts"></div>
				<div class="video-wrapper">
				'.$embed_url.'
				</div>
			</div>
			';
		}

		//Start Loop Breaking News Post
		endwhile;
		endif;
		wp_reset_postdata();

		if ($wp_query_args_video_posts->have_posts()) : $i=0; while ( $wp_query_args_video_posts->have_posts() ) : $wp_query_args_video_posts->the_post(); $i++;

		$views = cairo_get_post_views(get_the_ID());
		$post_information = '
      <li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
      <li class="post-data"><i class="fa fa-clock-o"></i>' . get_the_time( get_option( 'date_format' ) ) . '</li>
    ';

		$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-thumb-three' );
		$image = '<figure class="post-image">';
		$image .= '<img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" />';
		$image .= '</figure>';

		if($i == 1) {
			$output .= '<div class="col-md-4 col-sm-12 col-xs-12"><div class="row"><div class="video-playlist-style2 scrollbar-inner">';
		}

		$output .= '
			<article class="post post-overlay post-video-playlist col-md-12 col-sm-12 col-xs-12">
				<div class="video-slider">
					<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '" id="'.get_the_ID().'">
						'. $image . '
						<div class="post-title">
							<h5>'. get_the_title() .'</h5>
						</div>
						<div class="post-meta-box">
	    				<ul class="post-meta no-sep">
	    					'.$post_information.'
	    				</ul>
	          </div>
					</a>
				</div>
			</article>
		';


		//Start Loop Breaking News Post
    endwhile;
		endif;
		wp_reset_postdata();
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;


	endif;

}
add_shortcode("codepages_video_module", "codepages_video_posts");
