<?php
/**
 *
 * Category Posts Style
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function cairo_category_post( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'						 		=>	'',
			'postcount'			   		=>  '',
			'columnsection'				=>	'',
			'categorytitle'		 		=>  '',
			'titlestyle'			 		=>  '',
			'categoryorderby'	 		=>  '',
			'source'					 		=>  '',
			'cat'							 		=>	'',
			'excludecategory'	 		=>  '',
			'excludeposts'	   		=>  '',
			'excludetag'			 		=>  '',
			'author_ids'			 		=>  '',
			'autherimgdisplay'		=>	'',
			'postreview'					=>  '',
			'subcategorydisplay'	=>	'',
			'desdisplay'				 	=>	'',
			'metadisplay'				 	=>	'',
		), $atts
	);

	$output = '';

	//Start Exclude category
	if( !empty( $atts['excludecategory'] ) ) :
		$excludecategory = $atts['excludecategory'];
		$excludecategory = explode( ',', $excludecategory );
	else:
		$excludecategory = "";
	endif;

	//Start Exclude Tag
	if( !empty( $atts['excludetag'] ) ) :
		$excludetags = $atts['excludetag'];
		$excludetags = explode( ',', $excludetags );
	else:
		$excludetags = "";
	endif;

	//Start Exclude Posts
	if( !empty( $atts['excludeposts'] ) ) :
		$excludepost = $atts['excludeposts'];
		$excludepost = explode( ',', $excludepost );
	else:
		$excludepost = "";
	endif;

	//Start Exclude Category
	if( !empty( $atts['cat'] ) ) :
		$categorypost = $atts['cat'];
	else:
		$categorypost = "";
	endif;

	//Start Post ID
	if( !empty( $atts['postid'] ) ) :
		$bypostid = $atts['postid'];
		$bypostid = explode( ',', $bypostid );
	else:
		$bypostid = "";
	endif;

  //Start Category Order By
  if( !empty( $atts['categoryorderby'] ) ) :
  	$categoriesorderby = $atts['categoryorderby'];
  else:
  	$categoriesorderby = "";
  endif;

	if ($atts['subcategorydisplay']=='show') {
		$textcenter = '';
	}
	else{
		$textcenter = 'text-center';
	}

	//Start Get Category Posts
	$categories_category = $atts['cat'];
	if (!empty($atts['categorytitle'])) {
		$class_cat = '';
	}
	else{
		$class_cat = 'cat-color-module-'.$categories_category.'';
	}

  // ==========================================================================================
  // Category Posts Style 1
  // ==========================================================================================

	if( strstr( $atts['style'], "style1" ) ) :

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'posts_per_page' 				=> 6,
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		$subcategory =  wp_list_categories( array(
	  'child_of'	=> $atts['cat'],
      'orderby' => 'name',
      'echo' => false,
      'depth' => 4,
      'show_count' => false,
      'title_li' => false
     ));
		$categories  = get_categories(
			array(
				'child_of'	=> $atts['cat'],
			)
		);


		$output .= '<div class="category-content-module style1 '.$class_cat.'" data-style="style1">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';
		//Start Category Subcategory
		if ($atts['subcategorydisplay']=='show') {
			$output .= '<div class="subcategory pull-right"><nav id="nav-main" class="nav"><ul id="main" class="nav-list">';
			$output .= '<li><a href="javascript:void(0)" onclick="">'.esc_html__('All','cairo').'</a></li>';
				foreach ($categories  as $cat) {
					$output .= '<li class="cat-item cat-item-'.$cat->term_id.'">';
						$output .= '<a class="'.$cat->slug.'" id="'.$cat->term_id.'" onclick="" href="javascript:void(0)">'.$cat->name.'</a>';
					$output .= '</li>';
				}
			$output .= '<li class="more" data-width="80">
									<a href="javascript:void(0)">'.esc_html__('More','cairo').' <i class="fa fa-align-right"></i></a>
									<ul class="overflow"></ul>
									</li></ul></nav></div>';
		}
		$output .= '</div>';

		$output .= '<div class="module-content-wrapper">';
		$output .= '<div class="loading-posts"></div>';
		$output .= '<div class="custom-category-posts">';
		$output .= '<div class="row">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Post Description
		if ($atts['desdisplay']=='show') {
			$excerptlarg  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 20).'</p></div>';
		}
		else {
			$excerptlarg   = '';
		}

		//Start Auther Images
		if ($atts['autherimgdisplay']=='show') {
			$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
			$postauthorclass = 'author-images';
		} else {
			$postauthorimage = '';
			$postauthorclass = '';
		}
		$postauthorname = get_the_author_posts_link();

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		//Start Category Content
		$postClass = join( ' ',get_post_class() );

		$post_date = ' <span class="post-data"><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span> ';

		//Start Meta Post
		if ($atts['metadisplay']=='show') {
			$post_meta = '
			<li class="post-data"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
			<li class="post-data"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
			';
		}
		else {
			$post_meta   = '';
		}

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

    if ($i % 6 == 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-five' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
    }
    elseif ($i % 6 == 5 || $i % 6 == 4 || $i % 6 == 3 || $i % 6 == 2 || $i % 6 == 0) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-thumb-three' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';

			$post_categories = '';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    /*   Start Loop Posts     */
    if($i % 6 == 1) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-larg">';
    }
    if($i % 6 == 2) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-small">';
    }
		if($i % 6 == 1) {
		$output .= '
    <article class="'.$postClass.'">
        '. $image . '
  			'.$post_categories.'
  			'.$rating_number.'
        <div class="post-detail">
          <div class="post-title">
            <h3 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h3>
          </div>
					<div class="post-meta-info top '.$postauthorclass.'">
						<aside class="post-author">
						'.$postauthorimage.'
						'.$postauthorname.'
						</aside><!-- post-author -->
						'.$post_date.'
					</div><!-- post-meta -->
					'.$excerptlarg.'
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
							'.$post_meta.'
						</ul>
					</div><!-- post-meta -->
        </div>
    </article>
    ';
		}
		if($i % 6 == 5 || $i % 6 == 4 || $i % 6 == 3 || $i % 6 == 2 || $i % 6 == 0) {
		$output .= '
    <article class="'.$postClass.'">
        '. $image . '
  			'.$post_categories.'
        <div class="post-detail">
          <div class="post-title">
            <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
          </div>
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
    					'.$post_meta.'
    				</ul>
          </div>
        </div>
    </article>
    ';
		}
    if($i == 1) {
      $output .= '</div></div>';
    }
    if($i == 6) {
      $output .= '</div></div>';
    }
    ; endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */

		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';

		//Ajax-Data
		$style 		 			  	= $atts['style'];
		$postcount 			  	= $atts['postcount'];
		$columnsection 	  	= $atts['columnsection'];
		$categorytitle 	  	= $atts['categorytitle'];
		$titlestyle 		  	= $atts['titlestyle'];
		$categoryorderby  	= $atts['categoryorderby'];
		$source 				  	= $atts['source'];
		$cat   					  	= $atts['cat'];
		$excludecategory  	= $atts['excludecategory'];
		$excludeposts 	  	= $atts['excludeposts'];
		$excludetag 		  	= $atts['excludetag'];
		$author_ids 		  	= $atts['author_ids'];
		$autherimgdisplay 	= $atts['autherimgdisplay'];
		$postreview       	= $atts['postreview'];
		$subcategorydisplay = $atts['subcategorydisplay'];
		$desdisplay 				= $atts['desdisplay'];
		$metadisplay 				= $atts['metadisplay'];

		$output .= '<div class="ajax-block-data"
		data-style="'.$style.'"
		data-postcount="'.$postcount.'"
		data-columnsection="'.$columnsection.'"
		data-categorytitle="'.$categorytitle.'"
		data-titlestyle="'.$titlestyle.'"
		data-categoryorderby="'.$categoryorderby.'"
		data-source="'.$source.'"
		data-cat="'.$cat.'"
		data-excludecategory="'.$excludecategory.'"
		data-excludeposts="'.$excludeposts.'"
		data-excludetag="'.$excludetag.'"
		data-author_ids="'.$author_ids.'"
		data-autherimgdisplay="'.$autherimgdisplay.'"
		data-postreview="'.$postreview.'"
		data-subcategorydisplay="'.$subcategorydisplay.'"
		data-desdisplay="'.$desdisplay.'"
		data-metadisplay="'.$metadisplay.'"
		></div>';

		$output .= '</div><!-- category-content-module -->';
		return $output;

  // ==========================================================================================
  // Category Posts Style 2
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style2" ) ) :

		$postcount = $atts['postcount'];
		$postcount_default = '3';

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'posts_per_page' 				=> $atts['postcount'],
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		if (empty($atts['postcount'])) {
			$category_post_module = wp_parse_args(
				array(
					'posts_per_page' 	=> $postcount_default,
				)
			, $category_post_module );
		}

		$output .= '<div class="category-content-module style2 '.$class_cat.'" data-style="style-2">';
		$output .= '<div class="category-post-content">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';
		$output .= '</div>';

		$output .= '<div class="custom-category-posts">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Auther Images
		if ($atts['autherimgdisplay']=='show') {
			$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
			$postauthorclass = 'author-images';
		} else {
			$postauthorimage = '';
			$postauthorclass = '';
		}
		$postauthorname = get_the_author_posts_link();

		//Start Post Description
		if ($atts['desdisplay']=='show') {
			$excerptlarg  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 20).'</p></div><!-- post-entry -->';
			$excerptsmall  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 13).'</p></div><!-- post-entry -->';
		}
		else {
			$excerptlarg   = '';
			$excerptsmall   = '';
		}

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		//Start Category Content
		$postClass = join( ' ',get_post_class() );

		$post_date = ' <span class="post-data"><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span> ';

		//Start Meta Post
		if ($atts['metadisplay']=='show') {
			$post_meta = '
			<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
			<li class="post-data"><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></li>
			<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
			';
		}
		else {
			$post_meta   = '';
		}

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

    if ($i % 3 == 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-five' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
    }
    elseif ($i % 3 == 2 || $i % 3 == 0) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-thumb-three' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';

			$post_information = '
	      <li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
	      <li class="post-data"><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></li>
	    ';
			$post_categories = '';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;


    /*   Start Loop Posts     */
    if($i % 3 == 1) {
    $output .= '<div class="category-module-blocks block-category-larg">';
    }
    if($i % 3 == 2) {
    $output .= '<div class="category-module-blocks block-category-small">';
    }
		if($i % 3 == 1) {
		$output .= '
    <article class="'.$postClass.'">
      '. $image . '
			'.$post_categories.'
			'.$rating_number.'
      <div class="post-detail">
        <div class="post-title">
          <h3 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h3>
        </div>
				<div class="post-meta-info top '.$postauthorclass.'">
					<aside class="post-author">
					'.$postauthorimage.'
					'.$postauthorname.'
					</aside><!-- post-author -->
					'.$post_date.'
				</div><!-- post-meta -->
				'.$excerptlarg.'
				<div class="post-meta-box">
					<ul class="post-meta no-sep">
  					'.$post_meta.'
  				</ul>
        </div>
      </div>
    </article>
    ';
		}
		if($i % 3 == 2 || $i % 3 == 0) {
		$output .= '
    <article class="'.$postClass.'">
      '. $image . '
			'.$post_categories.'
      <div class="post-detail">
        <div class="post-title">
          <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
        </div>
				<div class="post-meta-box">
					<ul class="post-meta no-sep">
  					'.$post_information.'
  				</ul>
        </div>
      </div>
			'.$excerptsmall.'
    </article>
    ';
		}
    if($i % 3 == 1) {
      $output .= '</div>';
    }
    if($i % 3 == 0) {
      $output .= '</div>';
    }
    ; endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */

		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Category Posts Style 3
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style3" ) ) :

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'posts_per_page' 				=> '6',
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		if (empty($atts['postcount'])) {
			$postcount_default = '6';
			$category_post_module = wp_parse_args(
				array(
					'posts_per_page' 	=> $postcount_default,
				)
			, $category_post_module );
		}

		//Start Post Scount Block
		if ($atts['columnsection']=='style2') {
			$category_post_module = wp_parse_args(
				array(
					'posts_per_page' 	=> '8',
				)
			, $category_post_module );
		}

		$subcategory =  wp_list_categories( array(
		'child_of'	=> $atts['cat'],
			'orderby' => 'name',
			'echo' => false,
			'depth' => 4,
			'show_count' => false,
			'title_li' => false
		 ));
		$categories  = get_categories(
			array(
				'child_of'	=> $atts['cat'],
			)
		);

		$output .= '<div class="category-content-module style3 '.$class_cat.'" data-style="style3">';
		$output .= '<div class="category-post-content">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';

		//Start Category Subcategory
		if ($atts['subcategorydisplay']=='show') {
			$output .= '<div class="subcategory pull-right"><nav id="nav-main" class="nav"><ul id="main" class="nav-list">';
			$output .= '<li><a id="'.$atts['cat'].'" href="javascript:void(0)" onclick="">'.esc_html__('All','cairo').'</a></li>';
				foreach ($categories  as $cat) {
					$output .= '<li class="cat-item cat-item-'.$cat->term_id.'">';
						$output .= '<a class="'.$cat->slug.'" id="'.$cat->term_id.'" onclick="" href="javascript:void(0)">'.$cat->name.'</a>';
					$output .= '</li>';
				}
			$output .= '<li class="more" data-width="80">
									<a href="javascript:void(0)"> More <i class="fa fa-align-right"></i></a>
									<ul class="overflow"></ul>
									</li></ul></nav></div>';
		}

		$output .= '</div>';

		$output .= '<div class="module-content-wrapper">';
		$output .= '<div class="loading-posts"></div>';
		$output .= '<div class="custom-category-posts">';
		$output .= '<div class="custom-category-posts-wrapper">';
		$output .= '<div class="row">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();


		//Start Category Content
		$postClass = join( ' ',get_post_class() );

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
    $image = '<figure class="post-image">';
    $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
    $image .= '</figure>';

		$excerptdesc = cairo_string_limit_words(get_the_excerpt(), 12);

		$post_information = '
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		<li class="post-data"><a href="'.get_the_permalink().'"><i class="fa fa-clock-o"></i>' . get_the_time( get_option( 'date_format' ) ) . '</a></li>
		';

		$post_categories = '
		<div class="post-category category-bg-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    /*   Start Loop Posts     */

		if ($atts['columnsection']=='style2') {
		$output .= '<div class="col-md-3 col-sm-12 col-xs-12">';
		}
		else{
		$output .= '<div class="col-md-4 col-sm-6 col-xs-12">';
		}

		//Start Post Description
		if ($atts['desdisplay']=='show') {
			$excerptsmall  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 10).'</p></div><!-- post-entry -->';
		}
		else {
			$excerptsmall   = '';
		}


		$output .= '
    <article class="'.$postClass.' hover-style1">
        '. $image . '
				'.$rating_number.'
        <div class="post-detail">
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
								'.$post_information.'
						</ul>
					</div>
          <div class="post-title">
            <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
          </div>

        </div>
				'.$excerptsmall.'
    </article>
    ';
    $output .= '</div>';

    ; endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */

		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';

		//Ajax-Data
		$style 		 			  	= $atts['style'];
		$postcount 			  	= $atts['postcount'];
		$columnsection 	  	= $atts['columnsection'];
		$categorytitle 	  	= $atts['categorytitle'];
		$titlestyle 		  	= $atts['titlestyle'];
		$categoryorderby  	= $atts['categoryorderby'];
		$source 				  	= $atts['source'];
		$cat   					  	= $atts['cat'];
		$excludecategory  	= $atts['excludecategory'];
		$excludeposts 	  	= $atts['excludeposts'];
		$excludetag 		  	= $atts['excludetag'];
		$author_ids 		  	= $atts['author_ids'];
		$autherimgdisplay 	= $atts['autherimgdisplay'];
		$postreview       	= $atts['postreview'];
		$subcategorydisplay = $atts['subcategorydisplay'];
		$desdisplay 				= $atts['desdisplay'];
		$metadisplay 				= $atts['metadisplay'];

		$output .= '<div class="ajax-block-data"
		data-style="'.$style.'"
		data-postcount="'.$postcount.'"
		data-columnsection="'.$columnsection.'"
		data-categorytitle="'.$categorytitle.'"
		data-titlestyle="'.$titlestyle.'"
		data-categoryorderby="'.$categoryorderby.'"
		data-source="'.$source.'"
		data-cat="'.$cat.'"
		data-excludecategory="'.$excludecategory.'"
		data-excludeposts="'.$excludeposts.'"
		data-excludetag="'.$excludetag.'"
		data-author_ids="'.$author_ids.'"
		data-autherimgdisplay="'.$autherimgdisplay.'"
		data-postreview="'.$postreview.'"
		data-subcategorydisplay="'.$subcategorydisplay.'"
		data-desdisplay="'.$desdisplay.'"
		data-metadisplay="'.$metadisplay.'"
		></div>';

		$output .= '</div><!-- category-content-module -->';
		return $output;

  // ==========================================================================================
  // Category Posts Style 4
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style4" )) :

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		//Start Post Count
		$post_count = $atts['postcount'];
		if (empty($atts['postcount'])) {
			$category_post_module = wp_parse_args( array( 'posts_per_page' 	=> '6',), $category_post_module );
		}
		else{
			$category_post_module = wp_parse_args( array( 'posts_per_page' 	=> $post_count, ) , $category_post_module );
		}

		$subcategory =  wp_list_categories( array(
		'child_of'	=> $atts['cat'],
			'orderby' => 'name',
			'echo' => false,
			'depth' => 4,
			'show_count' => false,
			'title_li' => false
		 ));
		$categories  = get_categories(
			array(
				'child_of'	=> $atts['cat'],
			)
		);

		//Start Auther Images
		if ($atts['autherimgdisplay']=='show') {
			$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
			$postauthorclass = 'author-images';
		} else {
			$postauthorimage = '';
			$postauthorclass = '';
		}
		$postauthorname = get_the_author_posts_link();

		$output .= '<div class="category-content-module style4 '.$class_cat.'" data-style="style-4">';
		$output .= '<div class="category-post-content">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';

		//Start Category Subcategory
		if ($atts['subcategorydisplay']=='show') {
			$output .= '<div class="subcategory pull-right"><nav id="nav-main" class="nav"><ul id="main" class="nav-list">';
			$output .= '<li><a id="'.$atts['cat'].'" href="javascript:void(0)" onclick="">'.esc_html__('All','cairo').'</a></li>';
				foreach ($categories  as $cat) {
					$output .= '<li class="cat-item cat-item-'.$cat->term_id.'">';
						$output .= '<a class="'.$cat->slug.'" id="'.$cat->term_id.'" onclick="" href="javascript:void(0)">'.$cat->name.'</a>';
					$output .= '</li>';
				}
			$output .= '<li class="more" data-width="80">
									<a href="javascript:void(0)"> More <i class="fa fa-align-right"></i></a>
									<ul class="overflow"></ul>
									</li></ul></nav></div>';
		}

		$output .= '</div>';
		$output .= '</div>';

		$output .= '<div class="module-content-wrapper">';
		$output .= '<div class="loading-posts"></div>';
		$output .= '<div class="custom-category-posts">';
		$output .= '<div class="row">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Post Description
		if ($atts['desdisplay']=='show') {
			$excerptlarg  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 20).'</p></div>';
			$excerptsmall = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 10).'</p></div>';
		}
		else {
			$excerptlarg   = '';
			$excerptsmall  = '';
		}

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		//Start Category Content
		$postClass = join( ' ',get_post_class() );


		$post_meta = '
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		<li class="post-data"><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></li>
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		';

		$post_meta_small = '
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		';

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

    if ($i == 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-five' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
    }
    elseif ($i > 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-thumb-three' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';

			$post_categories = '';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    /*   Start Loop Posts     */
    if($i == 1) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-larg">';
		$output .= '
		<article class="'.$postClass.' post-style6 hover-style1">
			'. $image . '
			'.$rating_number.'
			<div class="post-detail">
				<div class="entry-header">
					'.$post_categories.'
					<div class="post-title">
						<h3 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h3>
					</div><!-- post-title -->
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
							'.$post_meta.'
						</ul>
					</div><!-- post-meta -->
				</div><!-- entry-header -->
			</div><!-- post-detail -->
		</article><!-- post -->
		';
		}

    if($i == 2) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-small scrollbar-inner">';
    }

		if($i > 1) {
		$output .= '
    <article class="'.$postClass.' hover-style1">
        '. $image . '
  			'.$post_categories.'
        <div class="post-detail">
          <div class="post-title">
            <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
          </div>
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
    					'.$post_meta_small.'
    				</ul>
          </div>
        </div>
				'.$excerptsmall.'
    </article>
    ';
		}

    if($i == 1) {
      $output .= '</div></div>';
    }

    ; endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */

		$output .= '</div></div>';
		$output .= '</div></div></div>';
		//Ajax-Data
		$style 		 			  	= $atts['style'];
		$postcount 			  	= $atts['postcount'];
		$columnsection 	  	= $atts['columnsection'];
		$categorytitle 	  	= $atts['categorytitle'];
		$titlestyle 		  	= $atts['titlestyle'];
		$categoryorderby  	= $atts['categoryorderby'];
		$source 				  	= $atts['source'];
		$cat   					  	= $atts['cat'];
		$excludecategory  	= $atts['excludecategory'];
		$excludeposts 	  	= $atts['excludeposts'];
		$excludetag 		  	= $atts['excludetag'];
		$author_ids 		  	= $atts['author_ids'];
		$autherimgdisplay 	= $atts['autherimgdisplay'];
		$postreview       	= $atts['postreview'];
		$subcategorydisplay = $atts['subcategorydisplay'];
		$desdisplay 				= $atts['desdisplay'];
		$metadisplay 				= $atts['metadisplay'];

		$output .= '<div class="ajax-block-data"
		data-style="'.$style.'"
		data-postcount="'.$postcount.'"
		data-columnsection="'.$columnsection.'"
		data-categorytitle="'.$categorytitle.'"
		data-titlestyle="'.$titlestyle.'"
		data-categoryorderby="'.$categoryorderby.'"
		data-source="'.$source.'"
		data-cat="'.$cat.'"
		data-excludecategory="'.$excludecategory.'"
		data-excludeposts="'.$excludeposts.'"
		data-excludetag="'.$excludetag.'"
		data-author_ids="'.$author_ids.'"
		data-autherimgdisplay="'.$autherimgdisplay.'"
		data-postreview="'.$postreview.'"
		data-subcategorydisplay="'.$subcategorydisplay.'"
		data-desdisplay="'.$desdisplay.'"
		data-metadisplay="'.$metadisplay.'"
		></div>';

		$output .= '</div><!-- category-content-module -->';
		return $output;

  // ==========================================================================================
  // Category Posts Style 5
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style5" )) :

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		//Start Post Count
		if ($atts['columnsection']=='style2') {
			$category_post_module = wp_parse_args( array( 'posts_per_page' 	=> '5',), $category_post_module );
		}
		else{
			$category_post_module = wp_parse_args( array( 'posts_per_page' 	=> '4', ) , $category_post_module );
		}

		//Start Auther Images
		if ($atts['autherimgdisplay']=='show') {
			$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
			$postauthorclass = 'author-images';
		} else {
			$postauthorimage = '';
			$postauthorclass = '';
		}
		$postauthorname = get_the_author_posts_link();

		$output .= '<div class="category-content-module style5 '.$class_cat.'" data-style="style-5">';
		$output .= '<div class="category-post-content">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';
		$output .= '</div>';

		$output .= '<div class="row">';
		$output .= '<div class="custom-category-posts">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Post Description
		$excerptsmall  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 10).'</p></div>';

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		//Start Category Content
		$postClass = join( ' ',get_post_class() );


		$post_meta = '
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		<li class="post-data"><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></li>
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		';

		$post_meta_small = '
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		';

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

    if ($i == 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-five' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
    }
    elseif ($i > 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';

			$post_categories = '';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    /*   Start Loop Posts     */
    if($i == 1) {
    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-larg">';
		$output .= '
		<article class="'.$postClass.' post-style7 hover-style1">
			'. $image . '
			'.$rating_number.'
			<div class="post-detail">
				<div class="entry-header">
					'.$post_categories.'
					<div class="post-title">
						<h1 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h1>
					</div><!-- post-title -->
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
							'.$post_meta.'
						</ul>
					</div><!-- post-meta -->
				</div><!-- entry-header -->
			</div><!-- post-detail -->
		</article><!-- post -->
		';
		}

    if($i == 2) {
	    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-small">';
	    $output .= '<div class="row">';
    }
		if($i > 1) {

		if ($atts['columnsection']=='style2') {
		$output .= '<div class="col-md-3 col-sm-12 col-xs-12">';
		}
		else{
		$output .= '<div class="col-md-4 col-sm-6 col-xs-12">';
		}
		$output .= '
    <article class="'.$postClass.' hover-style1">
        '. $image . '
  			'.$post_categories.'
				'.$rating_number.'
        <div class="post-detail">
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
							'.$post_meta_small.'
						</ul>
					</div>
          <div class="post-title">
            <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
          </div>
					'.$excerptsmall.'
        </div>
    </article>
    ';
		$output .= '</div>';
		}

    if($i == 1) {
      $output .= '</div></div>';
			$output .= '</div>';
    }

    ; endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */

		$output .= '</div></div>';
		$output .= '</div></div>';
		$output .= '</div></div>';
		return $output;

  // ==========================================================================================
  // Category Posts Style 6
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style6" )) :

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'posts_per_page'				=> 5,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		//Start Post Description
		if ($atts['desdisplay']=='show') {
			$excerptlarg  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 20).'</p></div>';
		}
		else {
			$excerptlarg   = '';
		}

		//Start Auther Images
		if ($atts['autherimgdisplay']=='show') {
			$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
			$postauthorclass = 'author-images';
		} else {
			$postauthorimage = '';
			$postauthorclass = '';
		}
		$postauthorname = get_the_author_posts_link();

		$output .= '<div class="category-content-module style6 '.$class_cat.'" data-style="style-6">';
		$output .= '<div class="category-post-content">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';
		$output .= '</div>';

		$output .= '<div class="row">';
		$output .= '<div class="custom-category-posts">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Post Description
		$excerpt  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 18).'</p></div>';

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		//Start Category Content
		$postClass = join( ' ',get_post_class() );

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

    if ($i == 3) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-four' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';
    }
    elseif ($i == 1 || $i == 2 || $i == 4 || $i == 5) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';
    }

		$post_meta = '
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		<li class="post-data"><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></li>
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		';

		$post_meta_small = '
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

		/*   Start Loop Posts     */
    if($i == 1) {
    $output .= '<div class="col-md-3 col-sm-12 col-xs-12 pull-left"><div class="category-module-blocks block-category-small">';
    }

    if($i == 1 || $i == 2) {
			$output .= '
	    <article class="'.$postClass.'">
	      '. $image . '
				'.$rating_number.'
				<div class="post-detail">
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
						'.$post_meta_small.'
						</ul>
					</div>
	        <div class="post-title">
	          <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
	        </div>
	      </div>
	    </article>
	   ';
    }

		if($i == 2) {
    $output .= '</div></div>';
    }


    if($i == 3) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-larg">';
    }
    if($i == 3) {
		$output .= '
		<article class="'.$postClass.'">
			'. $image . '
			'.$rating_number.'
			<div class="post-detail">
				<div class="post-title">
					<h2 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
				</div>
				<div class="post-meta-box">
					<ul class="post-meta no-sep">
					'.$post_meta.'
					</ul>
				</div>
				'.$excerpt.'
			</div>
		</article>
		';
    }
    if($i == 3) {
    $output .= '</div></div>';
    }

		if($i == 4) {
    $output .= '<div class="col-md-3 col-sm-12 col-xs-12 pull-left"><div class="category-module-blocks block-category-small">';
    }

    if($i == 4 || $i == 5) {
			$output .= '
	    <article class="'.$postClass.'">
	      '. $image . '
				'.$rating_number.'
	      <div class="post-detail">
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
						'.$post_meta_small.'
						</ul>
					</div>
	        <div class="post-title">
	          <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
	        </div>
	      </div>
	    </article>
	   ';
    }

		if($i == 5) {
    $output .= '</div></div>';
    }; endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */


		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Category Posts Style 7
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style7" )) :

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'posts_per_page' 				=> 4,
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		$subcategory =  wp_list_categories( array(
	  'child_of'	=> $atts['cat'],
      'orderby' => 'name',
      'echo' => false,
      'depth' => 4,
      'show_count' => false,
      'title_li' => false
     ));
		$categories  = get_categories(
			array(
				'child_of'	=> $atts['cat'],
			)
		);

		$output .= '<div class="category-content-module style7 '.$class_cat.'" data-style="style-7">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';

		//Start Category Subcategory
		if ($atts['subcategorydisplay']=='show') {
			$output .= '<div class="subcategory pull-right"><ul>';
			$output .= ''.$subcategory.'';
			$output .= '</ul></div>';
		}

		$output .= '</div>';

		$output .= '<div class="module-content-wrapper">';
		$output .= '<div class="loading-posts"></div>';
		$output .= '<div class="custom-category-posts">';
		$output .= '<div class="row">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Post Description
		$excerptlarg  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 25).'</p></div>';
		$excerptsmall  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 12).'</p></div>';

		//Start Auther Images
		$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
		$postauthorclass = 'author-images';
		$postauthorname = get_the_author_posts_link();

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		//Start Category Content
		$postClass = join( ' ',get_post_class() );

		//Start Meta Post
		$post_date = ' <span class="post-data"><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span> ';

		$post_meta_small = '
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		';

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

    if ($i % 4 == 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-five' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';
    }
    elseif ( $i % 4 == 3 || $i % 4 == 2 || $i % 4 == 0) {
      $image = '';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    /*   Start Loop Posts     */
    if($i % 4 == 1) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-larg">';
    }
    if($i % 4 == 2) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-small">';
    }
		if($i % 4 == 1) {
		$output .= '
    <article class="'.$postClass.'">
        '. $image . '
				'.$rating_number.'
        <div class="post-detail">
          <div class="post-title">
            <h3 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h3>
          </div>
					<div class="post-meta-info top">
						<aside class="post-author">
						'.$postauthorimage.'
						'.$postauthorname.'
						</aside><!-- post-author -->
						'.$post_date.'
					</div><!-- post-meta -->
					'.$excerptlarg.'
        </div>
    </article>
    ';
		}
		if ( $i % 4 == 3 || $i % 4 == 2 || $i % 4 == 0) {
		$output .= '
    <article class="'.$postClass.'">
        '. $image . '
        <div class="post-detail">
          <div class="post-title">
            <h4 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h4>
          </div>
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
							'.$post_meta_small.'
						</ul>
					</div>
					'.$excerptsmall.'
        </div>
    </article>
    ';
		}
    if($i % 4 == 1) {
      $output .= '</div></div>';
    }
    if($i % 4 == 0) {
      $output .= '</div></div>';
    }
    ; endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */

		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Category Posts Style 8
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style8" )) :

		$postcount = $atts['postcount'];
		$postcount_default = '7';

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'posts_per_page' 				=> $postcount,
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		if (empty($atts['postcount'])) {
			$category_post_module = wp_parse_args(
				array(
					'posts_per_page' 	=> $postcount_default,
				)
			, $category_post_module );
		}

		$subcategory =  wp_list_categories( array(
	  'child_of'	=> $atts['cat'],
      'orderby' => 'name',
      'echo' => false,
      'depth' => 4,
      'show_count' => false,
      'title_li' => false
     ));
		$categories  = get_categories(
			array(
				'child_of'	=> $atts['cat'],
			)
		);

		$output .= '<div class="category-content-module style8 '.$class_cat.'" data-style="style-8">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';
		$output .= '</div>';

		$output .= '<div class="module-content-wrapper">';
		$output .= '<div class="loading-posts"></div>';
		$output .= '<div class="custom-category-posts">';
		$output .= '<div class="row">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Post Description
		$excerptlarg   = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 25).'</p></div>';
		if ($atts['desdisplay']=='show') {
			$excerptsmall  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 12).'</p></div>';
		}
		else {
			$excerptsmall  = '';
		}

		//Start Auther Images
		$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
		$postauthorclass = 'author-images';
		$postauthorname = get_the_author_posts_link();

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		//Start Category Content
		$postClass = join( ' ',get_post_class() );

		//Start Meta Post
		$post_meta = '
		<div class="post-data item">'.get_the_time( get_option('date_format') ).'</div>
		';

		$post_meta_small = '
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		';

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    if ($i == 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-five' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= $rating_number;
			$image .= '</figure>';
    }
    elseif ($i > 1) {
			$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-thumb-one' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';
    }

		$post_categories = '
		<div class="post-category category-bg-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

    /*   Start Loop Posts     */
    if($i == 1) {
    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-larg row">';
    }
    if($i == 2) {
    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-small row">';
    }
		if($i == 1) {
		$output .= '
    <article class="'.$postClass.' post-style3">
			<div class="col-sm-5 col-xs-12">
				'. $image . '
			</div>
			<div class="col-sm-7 col-xs-12">
				<div class="post-detail">
					<div class="post-meta-info top">
						'.$post_categories.'
						'.$post_meta.'
					</div>
					<div class="post-title">
						<h3 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h3>
					</div>
					'.$excerptlarg.'
					<div class="post-meta bottom-meta">
						<aside class="post-author">
						'.$postauthorname.'
						</aside><!-- post-author -->
						<div class="post-meta-box">
							<ul class="post-meta no-sep">
								'.$post_meta_small.'
							</ul>
						</div>
					</div>
				</div>
			</div>
    </article>
    ';
		}
		if($i > 1) {
		$output .= '
		<div class="col-sm-6 col-xs-12">
    <article class="'.$postClass.'">
      '. $image . '
      <div class="post-detail">
        <div class="post-title">
          <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
        </div>
				<div class="post-meta-box">
					<ul class="post-meta no-sep">
  					'.$post_meta_small.'
  				</ul>
        </div>
      </div>
			'.$excerptsmall.'
    </article>
		</div>
    ';
		}
    if($i == 1) {
      $output .= '</div></div>';
    }
    ; endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */

		$output .= '</div></div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Category Posts Style 9
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style9" )) :

		$postcount = $atts['postcount'];
		$postcount_default = '3';

		//Query Post
		$category_post_module = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['author_ids'],
			'posts_per_page' 				=> 3,
			'post_status'				    => 'publish',
			'orderby'  				   		=> $categoriesorderby,
			'cat' 									=> $categorypost,
			'category__not_in' 			=> $excludecategory,
			'tag__not_in'						=> $excludetags,
			'post__not_in'					=> $excludepost,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);


		$output .= '<div class="category-content-module style9 '.$class_cat.'" data-style="style-9">';

		//Start Category Title
		$posttitlestyle = $atts['titlestyle'];
		$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
		$output .= '<h4>';
			if (!empty($atts['categorytitle'])) {
				$output .= $atts['categorytitle'];
			}
			else{
				$output .= get_cat_name( $categorypost );
			}
		$output .= '</h4>';
		$output .= '</div>';

		$output .= '<div class="module-content-wrapper">';
		$output .= '<div class="loading-posts"></div>';
		$output .= '<div class="custom-category-posts">';
		$output .= '<div class="row">';

		$i = 0;
		$wp_query_args_latest_posts = new WP_Query( $category_post_module );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Post Description
		$excerptlarg  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 25).'</p></div>';
		$excerptsmall  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 10).'</p></div>';

		//Start Auther Images
		if ($atts['autherimgdisplay']=='show') {
			$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
			$postauthorclass = 'author-images';
		} else {
			$postauthorimage = '';
			$postauthorclass = '';
		}
		$postauthorname = get_the_author_posts_link();

		//Start Get Meta Posts
		$views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		//Start Category Content
		$postClass = join( ' ',get_post_class() );

		//Start Meta Post
		$post_date = '
		<div class="post-data item">'.get_the_time( get_option('date_format') ).'</div>
		';

		$post_meta_small = '
		<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
		<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
		';

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

    if ($i == 1) {
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-five' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';
    }
    elseif ($i > 1) {
			$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-four' );
      $image = '<figure class="post-image">';
      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
      $image .= '</figure>';
    }

		$post_categories = '
		<div class="post-category category-bg-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;


    /*   Start Loop Posts     */

		if($i==1) {
		$output .= '<div class="col-md-8 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-larg">';
		}

			if($i == 1) {
			$output .= '
			<article class="'.$postClass.'">
	        '. $image . '
					'.$rating_number.'
	        <div class="post-detail">
	          <div class="post-title">
	            <h2 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
	          </div>
						<div class="post-meta-info top '.$postauthorclass.'">
							<aside class="post-author">
							'.$postauthorimage.'
							'.$postauthorname.'
							</aside><!-- post-author -->
							'.$post_date.'
						</div><!-- post-meta -->
						'.$excerptlarg.'
						<div class="post-meta-box">
							<ul class="post-meta no-sep">
								'.$post_meta_small.'
							</ul>
						</div><!-- post-meta -->
	        </div>
	    </article>
			';

			}

		if($i==1) {
		$output .= '</div></div>';
		}


		if($i == 2) {
		$output .= ' <div class="col-md-4 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-small">';
		}
			if($i > 1){
			$output .= '
			<article class="'.$postClass.' hover-style1">
	        '. $image . '
					'.$rating_number.'
	        <div class="post-detail">
	          <div class="post-title">
	            <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
	          </div>
						<div class="post-meta-box">
							<ul class="post-meta no-sep">
	    					'.$post_meta_small.'
	    				</ul>
	          </div>
						'.$excerptsmall.'
	        </div>
	    </article>
			';
			}

		if($i == 3) {
		$output .='</div></div>';
		}

		endwhile;
		wp_reset_postdata();
    /*   End Loop Posts     */

		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

		// ==========================================================================================
	  // Category Posts Style 10
	  // ==========================================================================================

		elseif (strstr( $atts['style'], "styleten" )) :

			$postcount = $atts['postcount'];
			$postcount_default = '4';

			//Query Post
			$category_post_module = array(
				'post__in'							=> $bypostid,
				'author'								=> $atts['author_ids'],
				'posts_per_page' 				=> $postcount,
				'post_status'				    => 'publish',
				'orderby'  				   		=> $categoriesorderby,
				'cat' 									=> $categorypost,
				'category__not_in' 			=> $excludecategory,
				'tag__not_in'						=> $excludetags,
				'post__not_in'					=> $excludepost,
				'ignore_sticky_posts' 	=> true,
				'post_type' 						=> 'post'
			);

			if (empty($atts['postcount'])) {
				$category_post_module = wp_parse_args(
					array(
						'posts_per_page' 	=> $postcount_default,
					)
				, $category_post_module );
			}

			$subcategory =  wp_list_categories( array(
		  'child_of'	=> $atts['cat'],
	      'orderby' => 'name',
	      'echo' => false,
	      'depth' => 4,
	      'show_count' => false,
	      'title_li' => false
	     ));
			$categories  = get_categories(
				array(
					'child_of'	=> $atts['cat'],
				)
			);

			$output .= '<div class="category-content-module style10 '.$class_cat.'" data-style="style-10">';

			//Start Category Title
			$posttitlestyle = $atts['titlestyle'];
			$output .= '<div class="category-title module-title '.$posttitlestyle.'">';
			$output .= '<h4>';
				if (!empty($atts['categorytitle'])) {
					$output .= $atts['categorytitle'];
				}
				else{
					$output .= get_cat_name( $categorypost );
				}
			$output .= '</h4>';
			$output .= '</div>';

			$output .= '<div class="module-content-wrapper">';
			$output .= '<div class="loading-posts"></div>';
			$output .= '<div class="custom-category-posts">';
			$output .= '<div class="row">';

			$i = 0;
			$wp_query_args_latest_posts = new WP_Query( $category_post_module );
			while ( $wp_query_args_latest_posts->have_posts() ) :
			$wp_query_args_latest_posts->the_post();$i++;

			//Start Post Description
			$excerptlarg   = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 25).'</p></div>';
			if ($atts['desdisplay']=='show') {
				$excerptsmall  = '<div class="post-excerpt"><p>'. cairo_string_limit_words(get_the_excerpt(), 10).'</p></div>';
				$classexcerpt  = '';
			}
			else {
				$excerptsmall  = '';
				$classexcerpt  = 'excerptnone';
			}

			//Start Auther Images
			$postauthorimage = get_avatar( get_the_author_meta( 'ID' ), $size = '35' );
			$postauthorclass = 'author-images';
			$postauthorname = get_the_author_posts_link();

			//Start Get Meta Posts
			$views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			//Start Category Content
			$postClass = join( ' ',get_post_class() );

			//Start Meta Post
			$post_meta = '
			<div class="post-data item">'.get_the_time( get_option('date_format') ).'</div>
			';

			$post_meta_small = '
			<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>
			<li class="post-comment"><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</li>
			';

			//Start Get Category Posts
			$categories = get_the_category( get_the_ID() );
			$catname = $categories[0]->name;
			$class = strtolower($catname);
			$class = str_replace(' ', '-', $class);
			$class = sanitize_title($class);

			$categories_category = "";
			$categories_category = get_the_category( get_the_ID() );
			$categories_firstCategory = $categories_category[0]->cat_ID;

			//Start Post Rating
			$id = get_the_ID();
			if ($atts['postreview']=='on') :
				if(! get_post_meta($id, 'review_score', true)) :
					$rating_number = "";
				else:
					$ratings_count = get_post_meta($id, 'review_score', true);
					$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
				endif;
			else:
				$rating_number = "";
			endif;

	    if ($i == 1) {
	      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-five' );
	      $image = '<figure class="post-image">';
	      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= $rating_number;
				$image .= '</figure>';
	    }
	    elseif ($i > 1) {
				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
	      $image = '<figure class="post-image">';
	      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= $rating_number;
				$image .= '</figure>';
	    }

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';

	    /*   Start Loop Posts     */
	    if($i == 1) {
	    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-larg row">';
	    }
	    if($i == 2) {
	    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="category-module-blocks block-category-small row">';
	    }
			if($i == 1) {
			$output .= '
	    <article class="'.$postClass.' post-style3">
				<div class="col-sm-6 col-xs-12">
					'. $image . '
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="post-detail">
						<div class="post-meta-info top">
							'.$post_categories.'
							'.$post_meta.'
						</div>
						<div class="post-title">
							<h3 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h3>
						</div>
						'.$excerptlarg.'
						<div class="post-meta bottom-meta">
							<aside class="post-author">
							'.$postauthorname.'
							</aside><!-- post-author -->
							<div class="post-meta-box">
								<ul class="post-meta no-sep">
									'.$post_meta_small.'
								</ul>
							</div>
						</div>
					</div>
				</div>
	    </article>
	    ';
			}
			if($i > 1) {

			$output .= '<div class="col-md-4 col-sm-12 col-xs-12">';

			$output .= '
	    <article class="'.$postClass.' '.$classexcerpt.'">
	      '. $image . '
	      <div class="post-detail">
	        <div class="post-title">
	          <h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
	        </div>
					<div class="post-meta-box">
						<ul class="post-meta no-sep">
	  					'.$post_meta_small.'
	  				</ul>
	        </div>
					'.$excerptsmall.'
	      </div>
	    </article>
	    ';

			$output .= '</div>';

			}

	    if($i == 1) {
	      $output .= '</div></div>';
	    }
	    ; endwhile;
			wp_reset_postdata();
	    /*   End Loop Posts     */

 			$output .= '</div></div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			return $output;

	endif;

}
add_shortcode("cairo_category_module", "cairo_category_post");
