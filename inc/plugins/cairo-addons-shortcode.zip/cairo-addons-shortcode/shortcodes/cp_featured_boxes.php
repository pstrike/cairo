<?php
/**
 *
 * Featured Boxes Element
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_featured_boxes( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'							=>	'',
			'title_text'				=>  '',
			'link_block'				=>  '',
			'image'						=>  '',
			'extra_class'				=>  '',
			'extra_id'					=>  '',
		), $atts
	);

	$output = '';

	$modulestyle 				= $atts['style'];
	$blocktitle 				= $atts['title_text'];
	$blocklink 					= $atts['link_block'];
	$image 							= $atts['image'];
	$blockclass 				= $atts['extra_class'];
	$blockid    				= $atts['extra_id'];
	$content 						= wpb_js_remove_wpautop($content, true);
	$img 								= wp_get_attachment_image_src($atts["image"], "cairo-post-large-five");
	$href 							= vc_build_link($blocklink);

  // ==========================================================================================
  // Module Featured Boxes Style
  // ==========================================================================================

	$output .= '<div class="codepages-featured-boxes codepages-fb-'.$modulestyle.' '.$blockclass.'">';
	$output .= '<div class="codepages-featured-boxes-wrapper">';
		$output .= '
		<div class="home-links">
			<img src="'. $img[0].'">
			<div class="content-featured-box">
			';
			if($href['url'] !== ""){
				$url 			= ( isset( $href['url'] ) && $href['url'] !== '' ) ? $href['url']  : '';
				$target 		= ( isset( $href['target'] ) && $href['target'] !== '' ) ? "target='" . trim( $href['target'] ) . "'" : '';
				$link_title 	= ( isset( $href['title'] ) && $href['title'] !== '' ) ? "title='".$href['title']."'" : '';
				$link_text 	= ( isset( $href['title'] ) && $href['title'] !== '' ) ? ''.$href['title'].'' : '';
				$rel 			= ( isset( $href['rel'] ) && $href['rel'] !== '' ) ? "rel='".$href['rel']."'" : '';
			}
			$output .= '<h2><a '. $link_title .' ' . $rel . ' href = "' . $url .'" '.$target.'> '.$blocktitle.' </a></h2>';
			if ( !empty ( $content ) ) {
				$output .= '<p>'.$content.'</p> ';
			}
			$output .= '
			</div>
		</div>
		';
	$output .= '</div>';
	$output .= '</div>';
	return $output;

}
add_shortcode("codepages_featured_boxes_module", "codepages_featured_boxes");
