<?php
/**
 *
 * Gallery Module
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_gallery_images( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'							=>	'',
			'image'							=>  '',
		), $atts
	);

	$style = $atts['style'];
	$image = (!empty($atts['image']) ? $atts['image'] : '');
	$image = explode(",", $image);

	$output = '';

	// ==========================================================================================
  // Gallery Style 1
  // ==========================================================================================

	if( strstr( $atts['style'], "style1" ) ) :

 		$output .= '<div class="codepages-gallery codepages-gallery-'.$style.'" data-style="style-1">';
		$output .= '<div class="codepages-gallery-wrapper"><div class="post-gallery">';

		foreach ($image as $images) {
			$img = wp_get_attachment_image_src($images, "full");
			$output .= '<a href="'.$img[0].'" class="lightbox-image"><img src="'. $img[0].'"></a>';
		}
		$output .= '</div></div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Gallery Style 2
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style2" ) ) :

		$output .= '<div class="codepages-gallery codepages-gallery-'.$style.'" data-style="style-2">';
		$output .= '<div class="codepages-gallery-wrapper">';
			$output .= '
			<div class="featured-block">
			<ul class="featured-slider-posts slider-gallery">
			';
			foreach ($image as $images) {
				$img = wp_get_attachment_image_src($images, "cairo-post-large-five");
				$output .= '<li><img src="'. $img[0].'"></li>';
			}
			$output .='
			</ul>
			<div class="post-slide-nav">
				<div class="prev-nav"></div>
				<div class="next-nav"></div>
			</div>
			';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

	endif;

}
add_shortcode("codepages_gallery_module", "codepages_gallery_images");
