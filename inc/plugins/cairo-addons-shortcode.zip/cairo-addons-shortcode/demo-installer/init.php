<?php
/**
 * Version 0.0.3
 *
 * This file is just an example you can copy it to your theme and modify it to fit your own needs.
 * Watch the paths though.
 */
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Don't duplicate me!
if ( !class_exists( 'Radium_Theme_Demo_Data_Importer' ) ) {
	require_once(CP_ROOT. '/' . 'demo-installer/importer/radium-importer.php');
	require_once(CP_ROOT. '/' . 'demo-installer/importer/widget-importer.php');

	class Radium_Theme_Demo_Data_Importer extends Radium_Theme_Importer {

		/**
		 * Set framewok
		 *
		 * options that can be used are 'default', 'Cairo' or 'optiontree'
		 *
		 * @since 0.0.3
		 *
		 * @var string
		 */
		public $theme_options_framework = 'optiontree';

		/**
		 * Holds a copy of the object for easy reference.
		 *
		 * @since 0.0.1
		 *
		 * @var object
		 */
		private static $instance;

		/**
		 * Set the key to be used to store theme options
		 *
		 * @since 0.0.2
		 *
		 * @var string
		 */
		public $theme_option_name       = 'my_theme_options_name'; //set theme options name here (key used to save theme options). Optiontree option name will be set automatically

		/**
		 * Set name of the theme options file
		 *
		 * @since 0.0.2
		 *
		 * @var string
		 */
		public $theme_options_file_name = 'theme_options.txt';

		/**
		 * Set name of the content file
		 *
		 * @since 0.0.2
		 *
		 * @var string
		 */
		public $content_demo_file_name  = 'content.xml';

		/**
		 * Set name of the widgets json file
		 *
		 * @since 0.0.2
		 *
		 * @var string
		 */
		public $widgets_file_name       = 'widgets.wie';

		/**
		 * Holds a copy of the widget settings
		 *
		 * @since 0.0.2
		 *
		 * @var string
		 */
		public $widget_import_results;

		/**
		 * Constructor. Hooks all interactions to initialize the class.
		 *
		 * @since 0.0.1
		 */
		public function __construct() {

			$this->demo_files_path = CP_ROOT . '/demo-installer/demo-files/'; //can

			self::$instance = $this;
			parent::__construct();

		}

		public $content_demos  = array(
			'Default' => array('default', 'http://cairo.code-pages.com/thecairo'),
			// 'Fashion' => array('fashion', 'http://cairo.code-pages.com/cairo-fashion/'),
		);

		/**
		 * Add menus - the menus listed here largely depend on the ones registered in the theme
		 *
		 * @since 0.0.1
		 */
		public function set_demo_menus(){

			$main_menu = get_term_by('name', 'Main-Menu', 'nav_menu');
			$mobile_menu = get_term_by('name', 'Main-Menu', 'nav_menu');
			$topbar_menu = get_term_by('name', 'Top-Menu', 'nav_menu');
			$sticky_menu = get_term_by('name', 'Main-Menu', 'nav_menu');
			$footer_menu = get_term_by('name', 'Top-Menu', 'nav_menu');

			$main_menu_term_id = isset($main_menu->term_id) ? $main_menu->term_id : null;
			$mobile_menu_term_id = isset($mobile_menu->term_id) ? $mobile_menu->term_id : null;
			$topbar_menu_term_id = isset($topbar_menu->term_id) ? $topbar_menu->term_id : null;
			$sticky_menu_term_id = isset($sticky_menu->term_id) ? $sticky_menu->term_id : null;
			$footer_menu_term_id = isset($footer_menu->term_id) ? $footer_menu->term_id : null;

			set_theme_mod( 'nav_menu_locations', array(
				'primary' => $main_menu_term_id,
				'mobile' => $mobile_menu_term_id,
				'secondary' => $topbar_menu_term_id,
				'sticky' => $sticky_menu_term_id,
				'footer' => $footer_menu_term_id
				)
			);

			// Assign front page and blog page.
			$front_page_id = get_page_by_title( 'Homepage' );
			$blog_page_id  = get_page_by_title( 'Blog' );

			// WordPress Delete Post.
			wp_delete_post(1);

			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $front_page_id->ID );
			update_option( 'page_for_posts', $blog_page_id->ID );

		}

	}

	new Radium_Theme_Demo_Data_Importer;

}
